﻿using OxyPlot;
using OxyPlot.Axes;
using OxyPlot.Series;
using System;
using System.Collections.Generic;
using System.Windows.Forms;

namespace _13052017_galton
{
    public partial class Form1 : Form                                                       // класс окна приложения
    {
        private int level;                                                                  // текущая стадия эксперимента
        private Random rnd;                                                                 // объект-генератор случайной величины
        List<Label> labelBalls;
        List<PictureBox> balls;
        List<PictureBox> arrows;

        public Form1()                                                                      // конструктор окна
        {
            InitializeComponent();
            level = 0;
            rnd = new Random();
            tscbSpeed.SelectedIndex = 1;
        }

        private void HideBalls()                                                            // функция скрытия всех шаров на картинке
        {
            foreach (var item in balls)
            {
                item.Visible = false;
            }
        }

        private void HideArrows()                                                           // функция скрытия всех стрелок на картинке
        {
            foreach (var item in arrows)
            {
                item.Visible = false;
            }
        }

        private void ClearCounters()                                                        // функция обнуления всех счетчиков шаров
        {
            foreach (var item in labelBalls)
            {
                item.Text = "0";
            }
        }

        private int Sum()                                                                   // функция вычисления суммы шаров в ячейках
        {
            int sum = 0;
            foreach (var item in labelBalls)
            {
                sum += Convert.ToInt32(item.Text);
            }
            return sum;
        }

        private int Max()                                                                   // функция вычисления максимума шаров в ячейках
        {
            int max = 0;
            foreach (var item in labelBalls)
            {
                max = Math.Max(max, Convert.ToInt32(item.Text));
            }
            return max;
        }

        private bool CheckAmount()                                                          // функция-проверка, достинуто ли нужно число шаров в эксперименте
        {
            return Sum() >= Convert.ToInt32(tstAmount.Text);
        }

        private void timer_Tick(object sender, EventArgs e)                                 // обработчик одного "тика" таймера
        {
            if (CheckAmount())
            {
                timer.Stop();
                tstAmount.Enabled = true;
                tsbStart.Enabled = true;
                tsbStop.Enabled = false;
                tsbPlot.Enabled = true;
                return;
            }
            int val = rnd.Next(0, 2);

            if (level == 0)
            {
                ball0.Visible = true;
            }
            else if (level == 1)
            {
                ball0.Visible = false;
                arrow0.Visible = true;
            }
            else if (level == 2)
            {
                arrow0.Visible = false;
                if (val == 0)
                {
                    arrow1_1.Visible = true;
                }
                else
                {
                    arrow1_2.Visible = true;
                }
            }
            else if (level == 3)
            {
                if (arrow1_1.Visible)
                {
                    if (val == 0)
                    {
                        arrow2_1.Visible = true;
                    }
                    else
                    {
                        arrow2_2.Visible = true;
                    }
                }
                else
                {
                    if (val == 0)
                    {
                        arrow2_3.Visible = true;
                    }
                    else
                    {
                        arrow2_4.Visible = true;
                    }
                }
                arrow1_1.Visible = false;
                arrow1_2.Visible = false;
            }
            else if (level == 4)
            {
                if (arrow2_1.Visible)
                {
                    if (val == 0)
                    {
                        arrow3_1.Visible = true;
                    }
                    else
                    {
                        arrow3_2.Visible = true;
                    }
                }
                else if (arrow2_2.Visible || arrow2_3.Visible)
                {
                    if (val == 0)
                    {
                        arrow3_3.Visible = true;
                    }
                    else
                    {
                        arrow3_4.Visible = true;
                    }
                }
                else
                {
                    if (val == 0)
                    {
                        arrow3_5.Visible = true;
                    }
                    else
                    {
                        arrow3_6.Visible = true;
                    }
                }
                arrow2_1.Visible = false;
                arrow2_2.Visible = false;
                arrow2_3.Visible = false;
                arrow2_4.Visible = false;
            }
            else if (level == 5)
            {
                if (arrow3_1.Visible)
                {
                    if (val == 0)
                    {
                        arrow4_1.Visible = true;
                    }
                    else
                    {
                        arrow4_2.Visible = true;
                    }
                }
                else if (arrow3_2.Visible || arrow3_3.Visible)
                {
                    if (val == 0)
                    {
                        arrow4_3.Visible = true;
                    }
                    else
                    {
                        arrow4_4.Visible = true;
                    }
                }
                else if (arrow3_4.Visible || arrow3_5.Visible)
                {
                    if (val == 0)
                    {
                        arrow4_5.Visible = true;
                    }
                    else
                    {
                        arrow4_6.Visible = true;
                    }
                }
                else
                {
                    if (val == 0)
                    {
                        arrow4_7.Visible = true;
                    }
                    else
                    {
                        arrow4_8.Visible = true;
                    }
                }
                arrow3_1.Visible = false;
                arrow3_2.Visible = false;
                arrow3_3.Visible = false;
                arrow3_4.Visible = false;
                arrow3_5.Visible = false;
                arrow3_6.Visible = false;
            }
            else if (level == 6)
            {
                if (arrow4_1.Visible)
                {
                    if (val == 0)
                    {
                        arrow5_1.Visible = true;
                    }
                    else
                    {
                        arrow5_2.Visible = true;
                    }
                }
                else if (arrow4_2.Visible || arrow4_3.Visible)
                {
                    if (val == 0)
                    {
                        arrow5_3.Visible = true;
                    }
                    else
                    {
                        arrow5_4.Visible = true;
                    }
                }
                else if (arrow4_4.Visible || arrow4_5.Visible)
                {
                    if (val == 0)
                    {
                        arrow5_5.Visible = true;
                    }
                    else
                    {
                        arrow5_6.Visible = true;
                    }
                }
                else if (arrow4_6.Visible || arrow4_7.Visible)
                {
                    if (val == 0)
                    {
                        arrow5_7.Visible = true;
                    }
                    else
                    {
                        arrow5_8.Visible = true;
                    }
                }
                else
                {
                    if (val == 0)
                    {
                        arrow5_9.Visible = true;
                    }
                    else
                    {
                        arrow5_10.Visible = true;
                    }
                }
                arrow4_1.Visible = false;
                arrow4_2.Visible = false;
                arrow4_3.Visible = false;
                arrow4_4.Visible = false;
                arrow4_5.Visible = false;
                arrow4_6.Visible = false;
                arrow4_7.Visible = false;
                arrow4_8.Visible = false;
            }
            else if (level == 7)
            {
                if (arrow5_1.Visible)
                {
                    if (val == 0)
                    {
                        arrow6_1.Visible = true;
                    }
                    else
                    {
                        arrow6_2.Visible = true;
                    }
                }
                else if (arrow5_2.Visible || arrow5_3.Visible)
                {
                    if (val == 0)
                    {
                        arrow6_3.Visible = true;
                    }
                    else
                    {
                        arrow6_4.Visible = true;
                    }
                }
                else if (arrow5_4.Visible || arrow5_5.Visible)
                {
                    if (val == 0)
                    {
                        arrow6_5.Visible = true;
                    }
                    else
                    {
                        arrow6_6.Visible = true;
                    }
                }
                else if (arrow5_6.Visible || arrow5_7.Visible)
                {
                    if (val == 0)
                    {
                        arrow6_7.Visible = true;
                    }
                    else
                    {
                        arrow6_8.Visible = true;
                    }
                }
                else if (arrow5_8.Visible || arrow5_9.Visible)
                {
                    if (val == 0)
                    {
                        arrow6_9.Visible = true;
                    }
                    else
                    {
                        arrow6_10.Visible = true;
                    }
                }
                else
                {
                    if (val == 0)
                    {
                        arrow6_11.Visible = true;
                    }
                    else
                    {
                        arrow6_12.Visible = true;
                    }
                }
                arrow5_1.Visible = false;
                arrow5_2.Visible = false;
                arrow5_3.Visible = false;
                arrow5_4.Visible = false;
                arrow5_5.Visible = false;
                arrow5_6.Visible = false;
                arrow5_7.Visible = false;
                arrow5_8.Visible = false;
                arrow5_9.Visible = false;
                arrow5_10.Visible = false;
            }
            else if (level == 8)
            {
                if (arrow6_1.Visible)
                {
                    if (val == 0)
                    {
                        arrow7_1.Visible = true;
                    }
                    else
                    {
                        arrow7_2.Visible = true;
                    }
                }
                else if (arrow6_2.Visible || arrow6_3.Visible)
                {
                    if (val == 0)
                    {
                        arrow7_3.Visible = true;
                    }
                    else
                    {
                        arrow7_4.Visible = true;
                    }
                }
                else if (arrow6_4.Visible || arrow6_5.Visible)
                {
                    if (val == 0)
                    {
                        arrow7_5.Visible = true;
                    }
                    else
                    {
                        arrow7_6.Visible = true;
                    }
                }
                else if (arrow6_6.Visible || arrow6_7.Visible)
                {
                    if (val == 0)
                    {
                        arrow7_7.Visible = true;
                    }
                    else
                    {
                        arrow7_8.Visible = true;
                    }
                }
                else if (arrow6_8.Visible || arrow6_9.Visible)
                {
                    if (val == 0)
                    {
                        arrow7_9.Visible = true;
                    }
                    else
                    {
                        arrow7_10.Visible = true;
                    }
                }
                else if (arrow6_10.Visible || arrow6_11.Visible)
                {
                    if (val == 0)
                    {
                        arrow7_11.Visible = true;
                    }
                    else
                    {
                        arrow7_12.Visible = true;
                    }
                }
                else
                {
                    if (val == 0)
                    {
                        arrow7_13.Visible = true;
                    }
                    else
                    {
                        arrow7_14.Visible = true;
                    }
                }
                arrow6_1.Visible = false;
                arrow6_2.Visible = false;
                arrow6_3.Visible = false;
                arrow6_4.Visible = false;
                arrow6_5.Visible = false;
                arrow6_6.Visible = false;
                arrow6_7.Visible = false;
                arrow6_8.Visible = false;
                arrow6_9.Visible = false;
                arrow6_10.Visible = false;
                arrow6_11.Visible = false;
                arrow6_12.Visible = false;
            }
            else if (level == 9)
            {
                if (arrow7_1.Visible)
                {
                    if (val == 0)
                    {
                        arrow8_1.Visible = true;
                    }
                    else
                    {
                        arrow8_2.Visible = true;
                    }
                }
                else if (arrow7_2.Visible || arrow7_3.Visible)
                {
                    if (val == 0)
                    {
                        arrow8_3.Visible = true;
                    }
                    else
                    {
                        arrow8_4.Visible = true;
                    }
                }
                else if (arrow7_4.Visible || arrow7_5.Visible)
                {
                    if (val == 0)
                    {
                        arrow8_5.Visible = true;
                    }
                    else
                    {
                        arrow8_6.Visible = true;
                    }
                }
                else if (arrow7_6.Visible || arrow7_7.Visible)
                {
                    if (val == 0)
                    {
                        arrow8_7.Visible = true;
                    }
                    else
                    {
                        arrow8_8.Visible = true;
                    }
                }
                else if (arrow7_8.Visible || arrow7_9.Visible)
                {
                    if (val == 0)
                    {
                        arrow8_9.Visible = true;
                    }
                    else
                    {
                        arrow8_10.Visible = true;
                    }
                }
                else if (arrow7_10.Visible || arrow7_11.Visible)
                {
                    if (val == 0)
                    {
                        arrow8_11.Visible = true;
                    }
                    else
                    {
                        arrow8_12.Visible = true;
                    }
                }
                else if (arrow7_12.Visible || arrow7_13.Visible)
                {
                    if (val == 0)
                    {
                        arrow8_13.Visible = true;
                    }
                    else
                    {
                        arrow8_14.Visible = true;
                    }
                }
                else
                {
                    if (val == 0)
                    {
                        arrow8_15.Visible = true;
                    }
                    else
                    {
                        arrow8_16.Visible = true;
                    }
                }
                arrow7_1.Visible = false;
                arrow7_2.Visible = false;
                arrow7_3.Visible = false;
                arrow7_4.Visible = false;
                arrow7_5.Visible = false;
                arrow7_6.Visible = false;
                arrow7_7.Visible = false;
                arrow7_8.Visible = false;
                arrow7_9.Visible = false;
                arrow7_10.Visible = false;
                arrow7_11.Visible = false;
                arrow7_12.Visible = false;
                arrow7_13.Visible = false;
                arrow7_14.Visible = false;
            }
            else if (level == 10)
            {
                if (arrow8_1.Visible)
                {
                    if (val == 0)
                    {
                        arrow9_1.Visible = true;
                    }
                    else
                    {
                        arrow9_2.Visible = true;
                    }
                }
                else if (arrow8_2.Visible || arrow8_3.Visible)
                {
                    if (val == 0)
                    {
                        arrow9_3.Visible = true;
                    }
                    else
                    {
                        arrow9_4.Visible = true;
                    }
                }
                else if (arrow8_4.Visible || arrow8_5.Visible)
                {
                    if (val == 0)
                    {
                        arrow9_5.Visible = true;
                    }
                    else
                    {
                        arrow9_6.Visible = true;
                    }
                }
                else if (arrow8_6.Visible || arrow8_7.Visible)
                {
                    if (val == 0)
                    {
                        arrow9_7.Visible = true;
                    }
                    else
                    {
                        arrow9_8.Visible = true;
                    }
                }
                else if (arrow8_8.Visible || arrow8_9.Visible)
                {
                    if (val == 0)
                    {
                        arrow9_9.Visible = true;
                    }
                    else
                    {
                        arrow9_10.Visible = true;
                    }
                }
                else if (arrow8_10.Visible || arrow8_11.Visible)
                {
                    if (val == 0)
                    {
                        arrow9_11.Visible = true;
                    }
                    else
                    {
                        arrow9_12.Visible = true;
                    }
                }
                else if (arrow8_12.Visible || arrow8_13.Visible)
                {
                    if (val == 0)
                    {
                        arrow9_13.Visible = true;
                    }
                    else
                    {
                        arrow9_14.Visible = true;
                    }
                }
                else if (arrow8_14.Visible || arrow8_15.Visible)
                {
                    if (val == 0)
                    {
                        arrow9_15.Visible = true;
                    }
                    else
                    {
                        arrow9_16.Visible = true;
                    }
                }
                else
                {
                    if (val == 0)
                    {
                        arrow9_17.Visible = true;
                    }
                    else
                    {
                        arrow9_18.Visible = true;
                    }
                }
                arrow8_1.Visible = false;
                arrow8_2.Visible = false;
                arrow8_3.Visible = false;
                arrow8_4.Visible = false;
                arrow8_5.Visible = false;
                arrow8_6.Visible = false;
                arrow8_7.Visible = false;
                arrow8_8.Visible = false;
                arrow8_9.Visible = false;
                arrow8_10.Visible = false;
                arrow8_11.Visible = false;
                arrow8_12.Visible = false;
                arrow8_13.Visible = false;
                arrow8_14.Visible = false;
                arrow8_15.Visible = false;
                arrow8_16.Visible = false;
            }
            else if (level == 11)
            {
                if (arrow9_1.Visible)
                {
                    if (val == 0)
                    {
                        arrow10_1.Visible = true;
                    }
                    else
                    {
                        arrow10_2.Visible = true;
                    }
                }
                else if (arrow9_2.Visible || arrow9_3.Visible)
                {
                    if (val == 0)
                    {
                        arrow10_3.Visible = true;
                    }
                    else
                    {
                        arrow10_4.Visible = true;
                    }
                }
                else if (arrow9_4.Visible || arrow9_5.Visible)
                {
                    if (val == 0)
                    {
                        arrow10_5.Visible = true;
                    }
                    else
                    {
                        arrow10_6.Visible = true;
                    }
                }
                else if (arrow9_6.Visible || arrow9_7.Visible)
                {
                    if (val == 0)
                    {
                        arrow10_7.Visible = true;
                    }
                    else
                    {
                        arrow10_8.Visible = true;
                    }
                }
                else if (arrow9_8.Visible || arrow9_9.Visible)
                {
                    if (val == 0)
                    {
                        arrow10_9.Visible = true;
                    }
                    else
                    {
                        arrow10_10.Visible = true;
                    }
                }
                else if (arrow9_10.Visible || arrow9_11.Visible)
                {
                    if (val == 0)
                    {
                        arrow10_11.Visible = true;
                    }
                    else
                    {
                        arrow10_12.Visible = true;
                    }
                }
                else if (arrow9_12.Visible || arrow9_13.Visible)
                {
                    if (val == 0)
                    {
                        arrow10_13.Visible = true;
                    }
                    else
                    {
                        arrow10_14.Visible = true;
                    }
                }
                else if (arrow9_14.Visible || arrow9_15.Visible)
                {
                    if (val == 0)
                    {
                        arrow10_15.Visible = true;
                    }
                    else
                    {
                        arrow10_16.Visible = true;
                    }
                }
                else if (arrow9_16.Visible || arrow9_17.Visible)
                {
                    if (val == 0)
                    {
                        arrow10_17.Visible = true;
                    }
                    else
                    {
                        arrow10_18.Visible = true;
                    }
                }
                else
                {
                    if (val == 0)
                    {
                        arrow10_19.Visible = true;
                    }
                    else
                    {
                        arrow10_20.Visible = true;
                    }
                }
                arrow9_1.Visible = false;
                arrow9_2.Visible = false;
                arrow9_3.Visible = false;
                arrow9_4.Visible = false;
                arrow9_5.Visible = false;
                arrow9_6.Visible = false;
                arrow9_7.Visible = false;
                arrow9_8.Visible = false;
                arrow9_9.Visible = false;
                arrow9_10.Visible = false;
                arrow9_11.Visible = false;
                arrow9_12.Visible = false;
                arrow9_13.Visible = false;
                arrow9_14.Visible = false;
                arrow9_15.Visible = false;
                arrow9_16.Visible = false;
                arrow9_17.Visible = false;
                arrow9_18.Visible = false;
            }
            else if (level == 12)
            {
                if (arrow10_1.Visible)
                {
                    if (val == 0)
                    {
                        arrow11_1.Visible = true;
                    }
                    else
                    {
                        arrow11_2.Visible = true;
                    }
                }
                else if (arrow10_2.Visible || arrow10_3.Visible)
                {
                    if (val == 0)
                    {
                        arrow11_3.Visible = true;
                    }
                    else
                    {
                        arrow11_4.Visible = true;
                    }
                }
                else if (arrow10_4.Visible || arrow10_5.Visible)
                {
                    if (val == 0)
                    {
                        arrow11_5.Visible = true;
                    }
                    else
                    {
                        arrow11_6.Visible = true;
                    }
                }
                else if (arrow10_6.Visible || arrow10_7.Visible)
                {
                    if (val == 0)
                    {
                        arrow11_7.Visible = true;
                    }
                    else
                    {
                        arrow11_8.Visible = true;
                    }
                }
                else if (arrow10_8.Visible || arrow10_9.Visible)
                {
                    if (val == 0)
                    {
                        arrow11_9.Visible = true;
                    }
                    else
                    {
                        arrow11_10.Visible = true;
                    }
                }
                else if (arrow10_10.Visible || arrow10_11.Visible)
                {
                    if (val == 0)
                    {
                        arrow11_11.Visible = true;
                    }
                    else
                    {
                        arrow11_12.Visible = true;
                    }
                }
                else if (arrow10_12.Visible || arrow10_13.Visible)
                {
                    if (val == 0)
                    {
                        arrow11_13.Visible = true;
                    }
                    else
                    {
                        arrow11_14.Visible = true;
                    }
                }
                else if (arrow10_14.Visible || arrow10_15.Visible)
                {
                    if (val == 0)
                    {
                        arrow11_15.Visible = true;
                    }
                    else
                    {
                        arrow11_16.Visible = true;
                    }
                }
                else if (arrow10_16.Visible || arrow10_17.Visible)
                {
                    if (val == 0)
                    {
                        arrow11_17.Visible = true;
                    }
                    else
                    {
                        arrow11_18.Visible = true;
                    }
                }
                else if (arrow10_18.Visible || arrow10_19.Visible)
                {
                    if (val == 0)
                    {
                        arrow11_19.Visible = true;
                    }
                    else
                    {
                        arrow11_20.Visible = true;
                    }
                }
                else
                {
                    if (val == 0)
                    {
                        arrow11_21.Visible = true;
                    }
                    else
                    {
                        arrow11_22.Visible = true;
                    }
                }
                arrow10_1.Visible = false;
                arrow10_2.Visible = false;
                arrow10_3.Visible = false;
                arrow10_4.Visible = false;
                arrow10_5.Visible = false;
                arrow10_6.Visible = false;
                arrow10_7.Visible = false;
                arrow10_8.Visible = false;
                arrow10_9.Visible = false;
                arrow10_10.Visible = false;
                arrow10_11.Visible = false;
                arrow10_12.Visible = false;
                arrow10_13.Visible = false;
                arrow10_14.Visible = false;
                arrow10_15.Visible = false;
                arrow10_16.Visible = false;
                arrow10_17.Visible = false;
                arrow10_18.Visible = false;
                arrow10_19.Visible = false;
                arrow10_20.Visible = false;
            }
            else if (level == 13)
            {
                if (arrow11_1.Visible)
                {
                    if (val == 0)
                    {
                        arrow12_1.Visible = true;
                    }
                    else
                    {
                        arrow12_2.Visible = true;
                    }
                }
                else if (arrow11_2.Visible || arrow11_3.Visible)
                {
                    if (val == 0)
                    {
                        arrow12_3.Visible = true;
                    }
                    else
                    {
                        arrow12_4.Visible = true;
                    }
                }
                else if (arrow11_4.Visible || arrow11_5.Visible)
                {
                    if (val == 0)
                    {
                        arrow12_5.Visible = true;
                    }
                    else
                    {
                        arrow12_6.Visible = true;
                    }
                }
                else if (arrow11_6.Visible || arrow11_7.Visible)
                {
                    if (val == 0)
                    {
                        arrow12_7.Visible = true;
                    }
                    else
                    {
                        arrow12_8.Visible = true;
                    }
                }
                else if (arrow11_8.Visible || arrow11_9.Visible)
                {
                    if (val == 0)
                    {
                        arrow12_9.Visible = true;
                    }
                    else
                    {
                        arrow12_10.Visible = true;
                    }
                }
                else if (arrow11_10.Visible || arrow11_11.Visible)
                {
                    if (val == 0)
                    {
                        arrow12_11.Visible = true;
                    }
                    else
                    {
                        arrow12_12.Visible = true;
                    }
                }
                else if (arrow11_12.Visible || arrow11_13.Visible)
                {
                    if (val == 0)
                    {
                        arrow12_13.Visible = true;
                    }
                    else
                    {
                        arrow12_14.Visible = true;
                    }
                }
                else if (arrow11_14.Visible || arrow11_15.Visible)
                {
                    if (val == 0)
                    {
                        arrow12_15.Visible = true;
                    }
                    else
                    {
                        arrow12_16.Visible = true;
                    }
                }
                else if (arrow11_16.Visible || arrow11_17.Visible)
                {
                    if (val == 0)
                    {
                        arrow12_17.Visible = true;
                    }
                    else
                    {
                        arrow12_18.Visible = true;
                    }
                }
                else if (arrow11_18.Visible || arrow11_19.Visible)
                {
                    if (val == 0)
                    {
                        arrow12_19.Visible = true;
                    }
                    else
                    {
                        arrow12_20.Visible = true;
                    }
                }
                else if (arrow11_20.Visible || arrow11_21.Visible)
                {
                    if (val == 0)
                    {
                        arrow12_21.Visible = true;
                    }
                    else
                    {
                        arrow12_22.Visible = true;
                    }
                }
                else
                {
                    if (val == 0)
                    {
                        arrow12_23.Visible = true;
                    }
                    else
                    {
                        arrow12_24.Visible = true;
                    }
                }
                arrow11_1.Visible = false;
                arrow11_2.Visible = false;
                arrow11_3.Visible = false;
                arrow11_4.Visible = false;
                arrow11_5.Visible = false;
                arrow11_6.Visible = false;
                arrow11_7.Visible = false;
                arrow11_8.Visible = false;
                arrow11_9.Visible = false;
                arrow11_10.Visible = false;
                arrow11_11.Visible = false;
                arrow11_12.Visible = false;
                arrow11_13.Visible = false;
                arrow11_14.Visible = false;
                arrow11_15.Visible = false;
                arrow11_16.Visible = false;
                arrow11_17.Visible = false;
                arrow11_18.Visible = false;
                arrow11_19.Visible = false;
                arrow11_20.Visible = false;
                arrow11_21.Visible = false;
                arrow11_22.Visible = false;
            }
            else if (level == 14)
            {
                if (arrow12_1.Visible)
                {
                    ball1.Visible = true;
                }
                else if (arrow12_2.Visible || arrow12_3.Visible)
                {
                    ball2.Visible = true;
                }
                else if (arrow12_4.Visible || arrow12_5.Visible)
                {
                    ball3.Visible = true;
                }
                else if (arrow12_6.Visible || arrow12_7.Visible)
                {
                    ball4.Visible = true;
                }
                else if (arrow12_8.Visible || arrow12_9.Visible)
                {
                    ball5.Visible = true;
                }
                else if (arrow12_10.Visible || arrow12_11.Visible)
                {
                    ball6.Visible = true;
                }
                else if (arrow12_12.Visible || arrow12_13.Visible)
                {
                    ball7.Visible = true;
                }
                else if (arrow12_14.Visible || arrow12_15.Visible)
                {
                    ball8.Visible = true;
                }
                else if (arrow12_16.Visible || arrow12_17.Visible)
                {
                    ball9.Visible = true;
                }
                else if (arrow12_18.Visible || arrow12_19.Visible)
                {
                    ball10.Visible = true;
                }
                else if (arrow12_20.Visible || arrow12_21.Visible)
                {
                    ball11.Visible = true;
                }
                else if (arrow12_22.Visible || arrow12_23.Visible)
                {
                    ball12.Visible = true;
                }
                else
                {
                    ball13.Visible = true;
                }
                arrow12_1.Visible = false;
                arrow12_2.Visible = false;
                arrow12_3.Visible = false;
                arrow12_4.Visible = false;
                arrow12_5.Visible = false;
                arrow12_6.Visible = false;
                arrow12_7.Visible = false;
                arrow12_8.Visible = false;
                arrow12_9.Visible = false;
                arrow12_10.Visible = false;
                arrow12_11.Visible = false;
                arrow12_12.Visible = false;
                arrow12_13.Visible = false;
                arrow12_14.Visible = false;
                arrow12_15.Visible = false;
                arrow12_16.Visible = false;
                arrow12_17.Visible = false;
                arrow12_18.Visible = false;
                arrow12_19.Visible = false;
                arrow12_20.Visible = false;
                arrow12_21.Visible = false;
                arrow12_22.Visible = false;
                arrow12_23.Visible = false;
                arrow12_24.Visible = false;
            }
            else if (level == 15)
            {
                if (ball1.Visible)
                {
                    int count = Convert.ToInt32(labelBall1.Text);
                    count++;
                    labelBall1.Text = count.ToString();
                }
                else if (ball2.Visible)
                {
                    int count = Convert.ToInt32(labelBall2.Text);
                    count++;
                    labelBall2.Text = count.ToString();
                }
                else if (ball3.Visible)
                {
                    int count = Convert.ToInt32(labelBall3.Text);
                    count++;
                    labelBall3.Text = count.ToString();
                }
                else if (ball4.Visible)
                {
                    int count = Convert.ToInt32(labelBall4.Text);
                    count++;
                    labelBall4.Text = count.ToString();
                }
                else if (ball5.Visible)
                {
                    int count = Convert.ToInt32(labelBall5.Text);
                    count++;
                    labelBall5.Text = count.ToString();
                }
                else if (ball6.Visible)
                {
                    int count = Convert.ToInt32(labelBall6.Text);
                    count++;
                    labelBall6.Text = count.ToString();
                }
                else if (ball7.Visible)
                {
                    int count = Convert.ToInt32(labelBall7.Text);
                    count++;
                    labelBall7.Text = count.ToString();
                }
                else if (ball8.Visible)
                {
                    int count = Convert.ToInt32(labelBall8.Text);
                    count++;
                    labelBall8.Text = count.ToString();
                }
                else if (ball9.Visible)
                {
                    int count = Convert.ToInt32(labelBall9.Text);
                    count++;
                    labelBall9.Text = count.ToString();
                }
                else if (ball10.Visible)
                {
                    int count = Convert.ToInt32(labelBall10.Text);
                    count++;
                    labelBall10.Text = count.ToString();
                }
                else if (ball11.Visible)
                {
                    int count = Convert.ToInt32(labelBall11.Text);
                    count++;
                    labelBall11.Text = count.ToString();
                }
                else if (ball12.Visible)
                {
                    int count = Convert.ToInt32(labelBall12.Text);
                    count++;
                    labelBall12.Text = count.ToString();
                }
                else
                {
                    int count = Convert.ToInt32(labelBall13.Text);
                    count++;
                    labelBall13.Text = count.ToString();
                }
                foreach (PictureBox ball in balls)
                {
                    ball.Visible = false;
                }
                   
            }
            else if (level == 16)
            {
                HideBalls();
                HideArrows();
                level = -1;
            }
            level++;
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            this.Width = 488;
            labelBalls = new List<Label>()
            {
                labelBall1,labelBall2,labelBall3,labelBall4,
                labelBall5,labelBall6,labelBall7,labelBall8,
                labelBall9,labelBall10,labelBall11,labelBall12,labelBall13
            };

            balls = new List<PictureBox>()
            {
                ball0,ball1,ball2,ball3,ball4,ball5,ball6,
                ball7,ball8,ball9,ball10,ball11,ball12,ball13
            };

            arrows = new List<PictureBox>()
            {
                arrow0,arrow1_1,arrow1_2,

                arrow2_1,arrow2_2,
                arrow2_3,arrow2_4,

                arrow3_1,arrow3_2,arrow3_3,
                arrow3_4,arrow3_5,arrow3_6,

                arrow4_1,arrow4_2,arrow4_3,arrow4_4,
                arrow4_5,arrow4_6,arrow4_7,arrow4_8,

                arrow5_1,arrow5_2,arrow5_3,arrow5_4,arrow5_5,
                arrow5_6,arrow5_7,arrow5_8,arrow5_9,arrow5_10,

                arrow6_1,arrow6_2,arrow6_3,arrow6_4,arrow6_5, arrow6_6,
                arrow6_7,arrow6_8,arrow6_9,arrow6_10,arrow6_11,arrow6_12,

                arrow7_1,arrow7_2,arrow7_3,arrow7_4,arrow7_5,arrow7_6,arrow7_7,
                arrow7_8,arrow7_9,arrow7_10,arrow7_11,arrow7_12,arrow7_13,arrow7_14,

                arrow8_1,arrow8_2,arrow8_3,arrow8_4,arrow8_5,arrow8_6,arrow8_7,arrow8_8,
                arrow8_9,arrow8_10,arrow8_11,arrow8_12,arrow8_13,arrow8_14,arrow8_15,arrow8_16,

                arrow9_1,arrow9_2,arrow9_3,arrow9_4,arrow9_5,arrow9_6,arrow9_7,arrow9_8,arrow9_9,
                arrow9_10,arrow9_11,arrow9_12,arrow9_13,arrow9_14,arrow9_15,arrow9_16,arrow9_17,arrow9_18,

                arrow10_1,arrow10_2,arrow10_3,arrow10_4,arrow10_5,arrow10_6,arrow10_7,arrow10_8,arrow10_9,arrow10_10,
                arrow10_11,arrow10_12,arrow10_13,arrow10_14,arrow10_15,arrow10_16,arrow10_17,arrow10_18,arrow10_19,arrow10_20,

                arrow11_1,arrow11_2,arrow11_3,arrow11_4,arrow11_5,arrow11_6,arrow11_7,arrow11_8,arrow11_9,arrow11_10,arrow11_11,
                arrow11_12,arrow11_13,arrow11_14,arrow11_15,arrow11_16,arrow11_17,arrow11_18,arrow11_19,arrow11_20,arrow11_21,arrow11_22,

                arrow12_1,arrow12_2,arrow12_3,arrow12_4,arrow12_5,arrow12_6,arrow12_7,arrow12_8,arrow12_9,arrow12_10,arrow12_11,arrow12_12,
                arrow12_13,arrow12_14,arrow12_15,arrow12_16,arrow12_17,arrow12_18,arrow12_19,arrow12_20,arrow12_21,arrow12_22,arrow12_23,arrow12_24
            };

            HideBalls();
            HideArrows();
        }

        private void tsbStart_Click(object sender, EventArgs e)
        {
            ClearCounters();
            HideBalls();
            HideArrows();
            ChooseSpeed();
            timer.Start();
            tstAmount.Enabled = false;
            tsbStart.Enabled = false;
            tsbStop.Enabled = true;
        }

        private void tsbStop_Click(object sender, EventArgs e)
        {
            timer.Stop();
            tstAmount.Enabled = true;
            tsbStart.Enabled = true;
            tsbStop.Enabled = false;
            tsbPlot.Enabled = true;
        }

        private void tsbPlot_Click(object sender, EventArgs e)
        {
            this.Width = 786;
            this.Height = 515;
            tsbPlot.Enabled = false;
            var barSeries = new ColumnSeries
            {
                ItemsSource = new List<ColumnItem>(new[]
                {
                    new ColumnItem{ Value = Convert.ToInt32(labelBall1.Text) },
                    new ColumnItem{ Value = Convert.ToInt32(labelBall2.Text) },
                    new ColumnItem{ Value = Convert.ToInt32(labelBall3.Text) },
                    new ColumnItem{ Value = Convert.ToInt32(labelBall4.Text) },
                    new ColumnItem{ Value = Convert.ToInt32(labelBall5.Text) },
                    new ColumnItem{ Value = Convert.ToInt32(labelBall6.Text) },
                    new ColumnItem{ Value = Convert.ToInt32(labelBall7.Text) },
                    new ColumnItem{ Value = Convert.ToInt32(labelBall8.Text) },
                    new ColumnItem{ Value = Convert.ToInt32(labelBall9.Text) },
                    new ColumnItem{ Value = Convert.ToInt32(labelBall10.Text) },
                    new ColumnItem{ Value = Convert.ToInt32(labelBall11.Text) },
                    new ColumnItem{ Value = Convert.ToInt32(labelBall12.Text) },
                    new ColumnItem{ Value = Convert.ToInt32(labelBall13.Text) }
                }),
                LabelPlacement = LabelPlacement.Outside,
                LabelFormatString = "{0}"
            };

            var myModel = new PlotModel { Title = "Доска Гальтона" };
            myModel.Series.Add(barSeries);
            myModel.Axes.Add(new LinearAxis
            {
                Position = AxisPosition.Left,
                Maximum = 1.2 * Max(),
                Minimum = 0,
            });
            plot1.Model = myModel;
            plot1.ForeColor = System.Drawing.Color.White;
            plot1.BackColor = System.Drawing.Color.White;
            plot1.Visible = true;
        }

        private void tscbSpeed_SelectedIndexChanged(object sender, EventArgs e)
        {
            ChooseSpeed();
        }

        private void ChooseSpeed()
        {
            switch (tscbSpeed.Text)
            {
                case "Медл":
                    timer.Interval = 400;
                    break;
                case "Сред":
                    timer.Interval = 200;
                    break;
                case "Выс":
                    timer.Interval = 1;
                    break;
            }
        }
    }
}
