﻿namespace _13052017_galton
{
    partial class Form1
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.plot1 = new OxyPlot.WindowsForms.PlotView();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.ball0 = new System.Windows.Forms.PictureBox();
            this.arrow0 = new System.Windows.Forms.PictureBox();
            this.arrow1_1 = new System.Windows.Forms.PictureBox();
            this.arrow2_1 = new System.Windows.Forms.PictureBox();
            this.arrow3_1 = new System.Windows.Forms.PictureBox();
            this.arrow4_1 = new System.Windows.Forms.PictureBox();
            this.arrow5_1 = new System.Windows.Forms.PictureBox();
            this.arrow6_1 = new System.Windows.Forms.PictureBox();
            this.arrow7_1 = new System.Windows.Forms.PictureBox();
            this.arrow8_1 = new System.Windows.Forms.PictureBox();
            this.arrow9_1 = new System.Windows.Forms.PictureBox();
            this.arrow10_1 = new System.Windows.Forms.PictureBox();
            this.arrow11_1 = new System.Windows.Forms.PictureBox();
            this.arrow12_1 = new System.Windows.Forms.PictureBox();
            this.arrow12_3 = new System.Windows.Forms.PictureBox();
            this.arrow11_3 = new System.Windows.Forms.PictureBox();
            this.arrow10_3 = new System.Windows.Forms.PictureBox();
            this.arrow9_3 = new System.Windows.Forms.PictureBox();
            this.arrow8_3 = new System.Windows.Forms.PictureBox();
            this.arrow7_3 = new System.Windows.Forms.PictureBox();
            this.arrow6_3 = new System.Windows.Forms.PictureBox();
            this.arrow5_3 = new System.Windows.Forms.PictureBox();
            this.arrow4_3 = new System.Windows.Forms.PictureBox();
            this.arrow12_5 = new System.Windows.Forms.PictureBox();
            this.arrow11_5 = new System.Windows.Forms.PictureBox();
            this.arrow10_5 = new System.Windows.Forms.PictureBox();
            this.arrow9_5 = new System.Windows.Forms.PictureBox();
            this.arrow8_5 = new System.Windows.Forms.PictureBox();
            this.arrow7_5 = new System.Windows.Forms.PictureBox();
            this.arrow6_5 = new System.Windows.Forms.PictureBox();
            this.arrow5_5 = new System.Windows.Forms.PictureBox();
            this.arrow4_5 = new System.Windows.Forms.PictureBox();
            this.arrow3_5 = new System.Windows.Forms.PictureBox();
            this.arrow12_7 = new System.Windows.Forms.PictureBox();
            this.arrow11_7 = new System.Windows.Forms.PictureBox();
            this.arrow10_7 = new System.Windows.Forms.PictureBox();
            this.arrow9_7 = new System.Windows.Forms.PictureBox();
            this.arrow8_7 = new System.Windows.Forms.PictureBox();
            this.arrow7_7 = new System.Windows.Forms.PictureBox();
            this.arrow6_7 = new System.Windows.Forms.PictureBox();
            this.arrow5_7 = new System.Windows.Forms.PictureBox();
            this.arrow4_7 = new System.Windows.Forms.PictureBox();
            this.arrow12_9 = new System.Windows.Forms.PictureBox();
            this.arrow11_9 = new System.Windows.Forms.PictureBox();
            this.arrow10_9 = new System.Windows.Forms.PictureBox();
            this.arrow9_9 = new System.Windows.Forms.PictureBox();
            this.arrow8_9 = new System.Windows.Forms.PictureBox();
            this.arrow7_9 = new System.Windows.Forms.PictureBox();
            this.arrow6_9 = new System.Windows.Forms.PictureBox();
            this.arrow5_9 = new System.Windows.Forms.PictureBox();
            this.arrow12_11 = new System.Windows.Forms.PictureBox();
            this.arrow11_11 = new System.Windows.Forms.PictureBox();
            this.arrow10_11 = new System.Windows.Forms.PictureBox();
            this.arrow9_11 = new System.Windows.Forms.PictureBox();
            this.arrow8_11 = new System.Windows.Forms.PictureBox();
            this.arrow7_11 = new System.Windows.Forms.PictureBox();
            this.arrow6_11 = new System.Windows.Forms.PictureBox();
            this.arrow12_13 = new System.Windows.Forms.PictureBox();
            this.arrow11_13 = new System.Windows.Forms.PictureBox();
            this.arrow10_13 = new System.Windows.Forms.PictureBox();
            this.arrow9_13 = new System.Windows.Forms.PictureBox();
            this.arrow8_13 = new System.Windows.Forms.PictureBox();
            this.arrow7_13 = new System.Windows.Forms.PictureBox();
            this.arrow12_15 = new System.Windows.Forms.PictureBox();
            this.arrow11_15 = new System.Windows.Forms.PictureBox();
            this.arrow10_15 = new System.Windows.Forms.PictureBox();
            this.arrow9_15 = new System.Windows.Forms.PictureBox();
            this.arrow8_15 = new System.Windows.Forms.PictureBox();
            this.arrow12_17 = new System.Windows.Forms.PictureBox();
            this.arrow11_17 = new System.Windows.Forms.PictureBox();
            this.arrow10_17 = new System.Windows.Forms.PictureBox();
            this.arrow9_17 = new System.Windows.Forms.PictureBox();
            this.arrow12_19 = new System.Windows.Forms.PictureBox();
            this.arrow11_19 = new System.Windows.Forms.PictureBox();
            this.arrow10_19 = new System.Windows.Forms.PictureBox();
            this.arrow12_21 = new System.Windows.Forms.PictureBox();
            this.arrow11_21 = new System.Windows.Forms.PictureBox();
            this.arrow12_23 = new System.Windows.Forms.PictureBox();
            this.arrow12_24 = new System.Windows.Forms.PictureBox();
            this.arrow12_22 = new System.Windows.Forms.PictureBox();
            this.arrow11_22 = new System.Windows.Forms.PictureBox();
            this.arrow12_20 = new System.Windows.Forms.PictureBox();
            this.arrow11_20 = new System.Windows.Forms.PictureBox();
            this.arrow10_20 = new System.Windows.Forms.PictureBox();
            this.arrow12_18 = new System.Windows.Forms.PictureBox();
            this.arrow11_18 = new System.Windows.Forms.PictureBox();
            this.arrow10_18 = new System.Windows.Forms.PictureBox();
            this.arrow9_18 = new System.Windows.Forms.PictureBox();
            this.arrow12_16 = new System.Windows.Forms.PictureBox();
            this.arrow11_16 = new System.Windows.Forms.PictureBox();
            this.arrow10_16 = new System.Windows.Forms.PictureBox();
            this.arrow9_16 = new System.Windows.Forms.PictureBox();
            this.arrow8_16 = new System.Windows.Forms.PictureBox();
            this.arrow12_14 = new System.Windows.Forms.PictureBox();
            this.arrow11_14 = new System.Windows.Forms.PictureBox();
            this.arrow10_14 = new System.Windows.Forms.PictureBox();
            this.arrow9_14 = new System.Windows.Forms.PictureBox();
            this.arrow8_14 = new System.Windows.Forms.PictureBox();
            this.arrow7_14 = new System.Windows.Forms.PictureBox();
            this.arrow12_12 = new System.Windows.Forms.PictureBox();
            this.arrow11_12 = new System.Windows.Forms.PictureBox();
            this.arrow10_12 = new System.Windows.Forms.PictureBox();
            this.arrow9_12 = new System.Windows.Forms.PictureBox();
            this.arrow8_12 = new System.Windows.Forms.PictureBox();
            this.arrow7_12 = new System.Windows.Forms.PictureBox();
            this.arrow6_12 = new System.Windows.Forms.PictureBox();
            this.arrow12_10 = new System.Windows.Forms.PictureBox();
            this.arrow11_10 = new System.Windows.Forms.PictureBox();
            this.arrow10_10 = new System.Windows.Forms.PictureBox();
            this.arrow9_10 = new System.Windows.Forms.PictureBox();
            this.arrow8_10 = new System.Windows.Forms.PictureBox();
            this.arrow7_10 = new System.Windows.Forms.PictureBox();
            this.arrow6_10 = new System.Windows.Forms.PictureBox();
            this.arrow5_10 = new System.Windows.Forms.PictureBox();
            this.arrow12_8 = new System.Windows.Forms.PictureBox();
            this.arrow11_8 = new System.Windows.Forms.PictureBox();
            this.arrow10_8 = new System.Windows.Forms.PictureBox();
            this.arrow9_8 = new System.Windows.Forms.PictureBox();
            this.arrow8_8 = new System.Windows.Forms.PictureBox();
            this.arrow7_8 = new System.Windows.Forms.PictureBox();
            this.arrow6_8 = new System.Windows.Forms.PictureBox();
            this.arrow5_8 = new System.Windows.Forms.PictureBox();
            this.arrow4_8 = new System.Windows.Forms.PictureBox();
            this.arrow12_6 = new System.Windows.Forms.PictureBox();
            this.arrow11_6 = new System.Windows.Forms.PictureBox();
            this.arrow10_6 = new System.Windows.Forms.PictureBox();
            this.arrow9_6 = new System.Windows.Forms.PictureBox();
            this.arrow8_6 = new System.Windows.Forms.PictureBox();
            this.arrow7_6 = new System.Windows.Forms.PictureBox();
            this.arrow6_6 = new System.Windows.Forms.PictureBox();
            this.arrow5_6 = new System.Windows.Forms.PictureBox();
            this.arrow4_6 = new System.Windows.Forms.PictureBox();
            this.arrow3_6 = new System.Windows.Forms.PictureBox();
            this.arrow12_4 = new System.Windows.Forms.PictureBox();
            this.arrow11_4 = new System.Windows.Forms.PictureBox();
            this.arrow10_4 = new System.Windows.Forms.PictureBox();
            this.arrow9_4 = new System.Windows.Forms.PictureBox();
            this.arrow8_4 = new System.Windows.Forms.PictureBox();
            this.arrow7_4 = new System.Windows.Forms.PictureBox();
            this.arrow6_4 = new System.Windows.Forms.PictureBox();
            this.arrow5_4 = new System.Windows.Forms.PictureBox();
            this.arrow4_4 = new System.Windows.Forms.PictureBox();
            this.arrow3_4 = new System.Windows.Forms.PictureBox();
            this.arrow2_4 = new System.Windows.Forms.PictureBox();
            this.arrow12_2 = new System.Windows.Forms.PictureBox();
            this.arrow11_2 = new System.Windows.Forms.PictureBox();
            this.arrow10_2 = new System.Windows.Forms.PictureBox();
            this.arrow9_2 = new System.Windows.Forms.PictureBox();
            this.arrow8_2 = new System.Windows.Forms.PictureBox();
            this.arrow7_2 = new System.Windows.Forms.PictureBox();
            this.arrow6_2 = new System.Windows.Forms.PictureBox();
            this.arrow5_2 = new System.Windows.Forms.PictureBox();
            this.arrow4_2 = new System.Windows.Forms.PictureBox();
            this.arrow3_2 = new System.Windows.Forms.PictureBox();
            this.arrow2_2 = new System.Windows.Forms.PictureBox();
            this.arrow1_2 = new System.Windows.Forms.PictureBox();
            this.ball1 = new System.Windows.Forms.PictureBox();
            this.ball2 = new System.Windows.Forms.PictureBox();
            this.ball3 = new System.Windows.Forms.PictureBox();
            this.ball4 = new System.Windows.Forms.PictureBox();
            this.ball5 = new System.Windows.Forms.PictureBox();
            this.ball6 = new System.Windows.Forms.PictureBox();
            this.ball7 = new System.Windows.Forms.PictureBox();
            this.ball8 = new System.Windows.Forms.PictureBox();
            this.ball9 = new System.Windows.Forms.PictureBox();
            this.ball10 = new System.Windows.Forms.PictureBox();
            this.ball11 = new System.Windows.Forms.PictureBox();
            this.ball12 = new System.Windows.Forms.PictureBox();
            this.ball13 = new System.Windows.Forms.PictureBox();
            this.labelBall1 = new System.Windows.Forms.Label();
            this.labelBall2 = new System.Windows.Forms.Label();
            this.labelBall3 = new System.Windows.Forms.Label();
            this.labelBall4 = new System.Windows.Forms.Label();
            this.labelBall5 = new System.Windows.Forms.Label();
            this.labelBall6 = new System.Windows.Forms.Label();
            this.labelBall7 = new System.Windows.Forms.Label();
            this.labelBall8 = new System.Windows.Forms.Label();
            this.labelBall9 = new System.Windows.Forms.Label();
            this.labelBall10 = new System.Windows.Forms.Label();
            this.labelBall11 = new System.Windows.Forms.Label();
            this.labelBall12 = new System.Windows.Forms.Label();
            this.labelBall13 = new System.Windows.Forms.Label();
            this.timer = new System.Windows.Forms.Timer(this.components);
            this.notifyIcon1 = new System.Windows.Forms.NotifyIcon(this.components);
            this.toolStrip1 = new System.Windows.Forms.ToolStrip();
            this.tsbStart = new System.Windows.Forms.ToolStripButton();
            this.tsbStop = new System.Windows.Forms.ToolStripButton();
            this.tsbPlot = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripLabel1 = new System.Windows.Forms.ToolStripLabel();
            this.tstAmount = new System.Windows.Forms.ToolStripTextBox();
            this.toolStripLabel2 = new System.Windows.Forms.ToolStripLabel();
            this.tscbSpeed = new System.Windows.Forms.ToolStripComboBox();
            this.arrow3_3 = new System.Windows.Forms.PictureBox();
            this.arrow2_3 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ball0)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.arrow0)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.arrow1_1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.arrow2_1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.arrow3_1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.arrow4_1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.arrow5_1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.arrow6_1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.arrow7_1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.arrow8_1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.arrow9_1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.arrow10_1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.arrow11_1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.arrow12_1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.arrow12_3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.arrow11_3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.arrow10_3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.arrow9_3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.arrow8_3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.arrow7_3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.arrow6_3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.arrow5_3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.arrow4_3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.arrow12_5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.arrow11_5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.arrow10_5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.arrow9_5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.arrow8_5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.arrow7_5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.arrow6_5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.arrow5_5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.arrow4_5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.arrow3_5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.arrow12_7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.arrow11_7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.arrow10_7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.arrow9_7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.arrow8_7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.arrow7_7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.arrow6_7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.arrow5_7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.arrow4_7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.arrow12_9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.arrow11_9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.arrow10_9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.arrow9_9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.arrow8_9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.arrow7_9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.arrow6_9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.arrow5_9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.arrow12_11)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.arrow11_11)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.arrow10_11)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.arrow9_11)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.arrow8_11)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.arrow7_11)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.arrow6_11)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.arrow12_13)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.arrow11_13)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.arrow10_13)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.arrow9_13)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.arrow8_13)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.arrow7_13)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.arrow12_15)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.arrow11_15)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.arrow10_15)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.arrow9_15)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.arrow8_15)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.arrow12_17)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.arrow11_17)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.arrow10_17)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.arrow9_17)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.arrow12_19)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.arrow11_19)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.arrow10_19)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.arrow12_21)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.arrow11_21)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.arrow12_23)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.arrow12_24)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.arrow12_22)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.arrow11_22)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.arrow12_20)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.arrow11_20)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.arrow10_20)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.arrow12_18)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.arrow11_18)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.arrow10_18)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.arrow9_18)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.arrow12_16)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.arrow11_16)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.arrow10_16)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.arrow9_16)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.arrow8_16)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.arrow12_14)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.arrow11_14)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.arrow10_14)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.arrow9_14)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.arrow8_14)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.arrow7_14)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.arrow12_12)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.arrow11_12)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.arrow10_12)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.arrow9_12)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.arrow8_12)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.arrow7_12)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.arrow6_12)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.arrow12_10)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.arrow11_10)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.arrow10_10)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.arrow9_10)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.arrow8_10)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.arrow7_10)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.arrow6_10)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.arrow5_10)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.arrow12_8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.arrow11_8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.arrow10_8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.arrow9_8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.arrow8_8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.arrow7_8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.arrow6_8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.arrow5_8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.arrow4_8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.arrow12_6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.arrow11_6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.arrow10_6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.arrow9_6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.arrow8_6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.arrow7_6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.arrow6_6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.arrow5_6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.arrow4_6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.arrow3_6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.arrow12_4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.arrow11_4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.arrow10_4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.arrow9_4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.arrow8_4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.arrow7_4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.arrow6_4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.arrow5_4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.arrow4_4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.arrow3_4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.arrow2_4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.arrow12_2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.arrow11_2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.arrow10_2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.arrow9_2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.arrow8_2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.arrow7_2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.arrow6_2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.arrow5_2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.arrow4_2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.arrow3_2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.arrow2_2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.arrow1_2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ball1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ball2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ball3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ball4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ball5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ball6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ball7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ball8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ball9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ball10)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ball11)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ball12)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ball13)).BeginInit();
            this.toolStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.arrow3_3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.arrow2_3)).BeginInit();
            this.SuspendLayout();
            // 
            // plot1
            // 
            this.plot1.BackColor = System.Drawing.Color.White;
            this.plot1.Location = new System.Drawing.Point(478, 28);
            this.plot1.Name = "plot1";
            this.plot1.PanCursor = System.Windows.Forms.Cursors.Hand;
            this.plot1.Size = new System.Drawing.Size(280, 441);
            this.plot1.TabIndex = 0;
            this.plot1.Text = "plot1";
            this.plot1.ZoomHorizontalCursor = System.Windows.Forms.Cursors.SizeWE;
            this.plot1.ZoomRectangleCursor = System.Windows.Forms.Cursors.SizeNWSE;
            this.plot1.ZoomVerticalCursor = System.Windows.Forms.Cursors.SizeNS;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::_13052017_galton.Properties.Resources.Background1;
            this.pictureBox1.Location = new System.Drawing.Point(12, 30);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(453, 439);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // ball0
            // 
            this.ball0.Image = global::_13052017_galton.Properties.Resources.Ball;
            this.ball0.Location = new System.Drawing.Point(234, 32);
            this.ball0.Name = "ball0";
            this.ball0.Size = new System.Drawing.Size(13, 14);
            this.ball0.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.ball0.TabIndex = 1;
            this.ball0.TabStop = false;
            // 
            // arrow0
            // 
            this.arrow0.Image = global::_13052017_galton.Properties.Resources.Ball;
            this.arrow0.Location = new System.Drawing.Point(235, 47);
            this.arrow0.Name = "arrow0";
            this.arrow0.Size = new System.Drawing.Size(13, 14);
            this.arrow0.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.arrow0.TabIndex = 2;
            this.arrow0.TabStop = false;
            // 
            // arrow1_1
            // 
            this.arrow1_1.Image = global::_13052017_galton.Properties.Resources.Ball;
            this.arrow1_1.Location = new System.Drawing.Point(219, 66);
            this.arrow1_1.Name = "arrow1_1";
            this.arrow1_1.Size = new System.Drawing.Size(13, 14);
            this.arrow1_1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.arrow1_1.TabIndex = 3;
            this.arrow1_1.TabStop = false;
            // 
            // arrow2_1
            // 
            this.arrow2_1.Image = global::_13052017_galton.Properties.Resources.Ball;
            this.arrow2_1.Location = new System.Drawing.Point(202, 87);
            this.arrow2_1.Name = "arrow2_1";
            this.arrow2_1.Size = new System.Drawing.Size(13, 14);
            this.arrow2_1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.arrow2_1.TabIndex = 4;
            this.arrow2_1.TabStop = false;
            // 
            // arrow3_1
            // 
            this.arrow3_1.Image = global::_13052017_galton.Properties.Resources.Ball;
            this.arrow3_1.Location = new System.Drawing.Point(185, 104);
            this.arrow3_1.Name = "arrow3_1";
            this.arrow3_1.Size = new System.Drawing.Size(13, 14);
            this.arrow3_1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.arrow3_1.TabIndex = 5;
            this.arrow3_1.TabStop = false;
            // 
            // arrow4_1
            // 
            this.arrow4_1.Image = global::_13052017_galton.Properties.Resources.Ball;
            this.arrow4_1.Location = new System.Drawing.Point(169, 119);
            this.arrow4_1.Name = "arrow4_1";
            this.arrow4_1.Size = new System.Drawing.Size(13, 14);
            this.arrow4_1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.arrow4_1.TabIndex = 6;
            this.arrow4_1.TabStop = false;
            // 
            // arrow5_1
            // 
            this.arrow5_1.Image = global::_13052017_galton.Properties.Resources.Ball;
            this.arrow5_1.Location = new System.Drawing.Point(151, 136);
            this.arrow5_1.Name = "arrow5_1";
            this.arrow5_1.Size = new System.Drawing.Size(13, 14);
            this.arrow5_1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.arrow5_1.TabIndex = 7;
            this.arrow5_1.TabStop = false;
            // 
            // arrow6_1
            // 
            this.arrow6_1.Image = global::_13052017_galton.Properties.Resources.Ball;
            this.arrow6_1.Location = new System.Drawing.Point(135, 154);
            this.arrow6_1.Name = "arrow6_1";
            this.arrow6_1.Size = new System.Drawing.Size(13, 14);
            this.arrow6_1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.arrow6_1.TabIndex = 8;
            this.arrow6_1.TabStop = false;
            // 
            // arrow7_1
            // 
            this.arrow7_1.Image = global::_13052017_galton.Properties.Resources.Ball;
            this.arrow7_1.Location = new System.Drawing.Point(119, 170);
            this.arrow7_1.Name = "arrow7_1";
            this.arrow7_1.Size = new System.Drawing.Size(13, 14);
            this.arrow7_1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.arrow7_1.TabIndex = 9;
            this.arrow7_1.TabStop = false;
            // 
            // arrow8_1
            // 
            this.arrow8_1.Image = global::_13052017_galton.Properties.Resources.Ball;
            this.arrow8_1.Location = new System.Drawing.Point(102, 186);
            this.arrow8_1.Name = "arrow8_1";
            this.arrow8_1.Size = new System.Drawing.Size(13, 14);
            this.arrow8_1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.arrow8_1.TabIndex = 10;
            this.arrow8_1.TabStop = false;
            // 
            // arrow9_1
            // 
            this.arrow9_1.Image = global::_13052017_galton.Properties.Resources.Ball;
            this.arrow9_1.Location = new System.Drawing.Point(85, 203);
            this.arrow9_1.Name = "arrow9_1";
            this.arrow9_1.Size = new System.Drawing.Size(13, 14);
            this.arrow9_1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.arrow9_1.TabIndex = 11;
            this.arrow9_1.TabStop = false;
            // 
            // arrow10_1
            // 
            this.arrow10_1.Image = global::_13052017_galton.Properties.Resources.Ball;
            this.arrow10_1.Location = new System.Drawing.Point(68, 221);
            this.arrow10_1.Name = "arrow10_1";
            this.arrow10_1.Size = new System.Drawing.Size(13, 14);
            this.arrow10_1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.arrow10_1.TabIndex = 12;
            this.arrow10_1.TabStop = false;
            // 
            // arrow11_1
            // 
            this.arrow11_1.Image = global::_13052017_galton.Properties.Resources.Ball;
            this.arrow11_1.Location = new System.Drawing.Point(51, 238);
            this.arrow11_1.Name = "arrow11_1";
            this.arrow11_1.Size = new System.Drawing.Size(13, 14);
            this.arrow11_1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.arrow11_1.TabIndex = 13;
            this.arrow11_1.TabStop = false;
            // 
            // arrow12_1
            // 
            this.arrow12_1.Image = global::_13052017_galton.Properties.Resources.Ball;
            this.arrow12_1.Location = new System.Drawing.Point(34, 258);
            this.arrow12_1.Name = "arrow12_1";
            this.arrow12_1.Size = new System.Drawing.Size(13, 14);
            this.arrow12_1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.arrow12_1.TabIndex = 14;
            this.arrow12_1.TabStop = false;
            // 
            // arrow12_3
            // 
            this.arrow12_3.Image = global::_13052017_galton.Properties.Resources.Ball;
            this.arrow12_3.Location = new System.Drawing.Point(68, 257);
            this.arrow12_3.Name = "arrow12_3";
            this.arrow12_3.Size = new System.Drawing.Size(13, 14);
            this.arrow12_3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.arrow12_3.TabIndex = 26;
            this.arrow12_3.TabStop = false;
            // 
            // arrow11_3
            // 
            this.arrow11_3.Image = global::_13052017_galton.Properties.Resources.Ball;
            this.arrow11_3.Location = new System.Drawing.Point(85, 237);
            this.arrow11_3.Name = "arrow11_3";
            this.arrow11_3.Size = new System.Drawing.Size(13, 14);
            this.arrow11_3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.arrow11_3.TabIndex = 25;
            this.arrow11_3.TabStop = false;
            // 
            // arrow10_3
            // 
            this.arrow10_3.Image = global::_13052017_galton.Properties.Resources.Ball;
            this.arrow10_3.Location = new System.Drawing.Point(102, 221);
            this.arrow10_3.Name = "arrow10_3";
            this.arrow10_3.Size = new System.Drawing.Size(13, 14);
            this.arrow10_3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.arrow10_3.TabIndex = 24;
            this.arrow10_3.TabStop = false;
            // 
            // arrow9_3
            // 
            this.arrow9_3.Image = global::_13052017_galton.Properties.Resources.Ball;
            this.arrow9_3.Location = new System.Drawing.Point(119, 203);
            this.arrow9_3.Name = "arrow9_3";
            this.arrow9_3.Size = new System.Drawing.Size(13, 14);
            this.arrow9_3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.arrow9_3.TabIndex = 23;
            this.arrow9_3.TabStop = false;
            // 
            // arrow8_3
            // 
            this.arrow8_3.Image = global::_13052017_galton.Properties.Resources.Ball;
            this.arrow8_3.Location = new System.Drawing.Point(135, 185);
            this.arrow8_3.Name = "arrow8_3";
            this.arrow8_3.Size = new System.Drawing.Size(13, 14);
            this.arrow8_3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.arrow8_3.TabIndex = 22;
            this.arrow8_3.TabStop = false;
            // 
            // arrow7_3
            // 
            this.arrow7_3.Image = global::_13052017_galton.Properties.Resources.Ball;
            this.arrow7_3.Location = new System.Drawing.Point(151, 170);
            this.arrow7_3.Name = "arrow7_3";
            this.arrow7_3.Size = new System.Drawing.Size(13, 14);
            this.arrow7_3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.arrow7_3.TabIndex = 21;
            this.arrow7_3.TabStop = false;
            // 
            // arrow6_3
            // 
            this.arrow6_3.Image = global::_13052017_galton.Properties.Resources.Ball;
            this.arrow6_3.Location = new System.Drawing.Point(169, 153);
            this.arrow6_3.Name = "arrow6_3";
            this.arrow6_3.Size = new System.Drawing.Size(13, 14);
            this.arrow6_3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.arrow6_3.TabIndex = 20;
            this.arrow6_3.TabStop = false;
            // 
            // arrow5_3
            // 
            this.arrow5_3.Image = global::_13052017_galton.Properties.Resources.Ball;
            this.arrow5_3.Location = new System.Drawing.Point(186, 135);
            this.arrow5_3.Name = "arrow5_3";
            this.arrow5_3.Size = new System.Drawing.Size(13, 14);
            this.arrow5_3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.arrow5_3.TabIndex = 19;
            this.arrow5_3.TabStop = false;
            // 
            // arrow4_3
            // 
            this.arrow4_3.Image = global::_13052017_galton.Properties.Resources.Ball;
            this.arrow4_3.Location = new System.Drawing.Point(204, 118);
            this.arrow4_3.Name = "arrow4_3";
            this.arrow4_3.Size = new System.Drawing.Size(13, 14);
            this.arrow4_3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.arrow4_3.TabIndex = 18;
            this.arrow4_3.TabStop = false;
            // 
            // arrow12_5
            // 
            this.arrow12_5.Image = global::_13052017_galton.Properties.Resources.Ball;
            this.arrow12_5.Location = new System.Drawing.Point(101, 257);
            this.arrow12_5.Name = "arrow12_5";
            this.arrow12_5.Size = new System.Drawing.Size(13, 14);
            this.arrow12_5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.arrow12_5.TabIndex = 38;
            this.arrow12_5.TabStop = false;
            // 
            // arrow11_5
            // 
            this.arrow11_5.Image = global::_13052017_galton.Properties.Resources.Ball;
            this.arrow11_5.Location = new System.Drawing.Point(118, 237);
            this.arrow11_5.Name = "arrow11_5";
            this.arrow11_5.Size = new System.Drawing.Size(13, 14);
            this.arrow11_5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.arrow11_5.TabIndex = 37;
            this.arrow11_5.TabStop = false;
            // 
            // arrow10_5
            // 
            this.arrow10_5.Image = global::_13052017_galton.Properties.Resources.Ball;
            this.arrow10_5.Location = new System.Drawing.Point(135, 221);
            this.arrow10_5.Name = "arrow10_5";
            this.arrow10_5.Size = new System.Drawing.Size(13, 14);
            this.arrow10_5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.arrow10_5.TabIndex = 36;
            this.arrow10_5.TabStop = false;
            // 
            // arrow9_5
            // 
            this.arrow9_5.Image = global::_13052017_galton.Properties.Resources.Ball;
            this.arrow9_5.Location = new System.Drawing.Point(152, 203);
            this.arrow9_5.Name = "arrow9_5";
            this.arrow9_5.Size = new System.Drawing.Size(13, 14);
            this.arrow9_5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.arrow9_5.TabIndex = 35;
            this.arrow9_5.TabStop = false;
            // 
            // arrow8_5
            // 
            this.arrow8_5.Image = global::_13052017_galton.Properties.Resources.Ball;
            this.arrow8_5.Location = new System.Drawing.Point(169, 186);
            this.arrow8_5.Name = "arrow8_5";
            this.arrow8_5.Size = new System.Drawing.Size(13, 14);
            this.arrow8_5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.arrow8_5.TabIndex = 34;
            this.arrow8_5.TabStop = false;
            // 
            // arrow7_5
            // 
            this.arrow7_5.Image = global::_13052017_galton.Properties.Resources.Ball;
            this.arrow7_5.Location = new System.Drawing.Point(186, 169);
            this.arrow7_5.Name = "arrow7_5";
            this.arrow7_5.Size = new System.Drawing.Size(13, 14);
            this.arrow7_5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.arrow7_5.TabIndex = 33;
            this.arrow7_5.TabStop = false;
            // 
            // arrow6_5
            // 
            this.arrow6_5.Image = global::_13052017_galton.Properties.Resources.Ball;
            this.arrow6_5.Location = new System.Drawing.Point(202, 152);
            this.arrow6_5.Name = "arrow6_5";
            this.arrow6_5.Size = new System.Drawing.Size(13, 14);
            this.arrow6_5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.arrow6_5.TabIndex = 32;
            this.arrow6_5.TabStop = false;
            // 
            // arrow5_5
            // 
            this.arrow5_5.Image = global::_13052017_galton.Properties.Resources.Ball;
            this.arrow5_5.Location = new System.Drawing.Point(220, 135);
            this.arrow5_5.Name = "arrow5_5";
            this.arrow5_5.Size = new System.Drawing.Size(13, 14);
            this.arrow5_5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.arrow5_5.TabIndex = 31;
            this.arrow5_5.TabStop = false;
            // 
            // arrow4_5
            // 
            this.arrow4_5.Image = global::_13052017_galton.Properties.Resources.Ball;
            this.arrow4_5.Location = new System.Drawing.Point(238, 118);
            this.arrow4_5.Name = "arrow4_5";
            this.arrow4_5.Size = new System.Drawing.Size(13, 14);
            this.arrow4_5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.arrow4_5.TabIndex = 30;
            this.arrow4_5.TabStop = false;
            // 
            // arrow3_5
            // 
            this.arrow3_5.Image = global::_13052017_galton.Properties.Resources.Ball;
            this.arrow3_5.Location = new System.Drawing.Point(255, 103);
            this.arrow3_5.Name = "arrow3_5";
            this.arrow3_5.Size = new System.Drawing.Size(13, 14);
            this.arrow3_5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.arrow3_5.TabIndex = 29;
            this.arrow3_5.TabStop = false;
            // 
            // arrow12_7
            // 
            this.arrow12_7.Image = global::_13052017_galton.Properties.Resources.Ball;
            this.arrow12_7.Location = new System.Drawing.Point(135, 257);
            this.arrow12_7.Name = "arrow12_7";
            this.arrow12_7.Size = new System.Drawing.Size(13, 14);
            this.arrow12_7.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.arrow12_7.TabIndex = 50;
            this.arrow12_7.TabStop = false;
            // 
            // arrow11_7
            // 
            this.arrow11_7.Image = global::_13052017_galton.Properties.Resources.Ball;
            this.arrow11_7.Location = new System.Drawing.Point(152, 237);
            this.arrow11_7.Name = "arrow11_7";
            this.arrow11_7.Size = new System.Drawing.Size(13, 14);
            this.arrow11_7.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.arrow11_7.TabIndex = 49;
            this.arrow11_7.TabStop = false;
            // 
            // arrow10_7
            // 
            this.arrow10_7.Image = global::_13052017_galton.Properties.Resources.Ball;
            this.arrow10_7.Location = new System.Drawing.Point(169, 221);
            this.arrow10_7.Name = "arrow10_7";
            this.arrow10_7.Size = new System.Drawing.Size(13, 14);
            this.arrow10_7.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.arrow10_7.TabIndex = 48;
            this.arrow10_7.TabStop = false;
            // 
            // arrow9_7
            // 
            this.arrow9_7.Image = global::_13052017_galton.Properties.Resources.Ball;
            this.arrow9_7.Location = new System.Drawing.Point(186, 203);
            this.arrow9_7.Name = "arrow9_7";
            this.arrow9_7.Size = new System.Drawing.Size(13, 14);
            this.arrow9_7.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.arrow9_7.TabIndex = 47;
            this.arrow9_7.TabStop = false;
            // 
            // arrow8_7
            // 
            this.arrow8_7.Image = global::_13052017_galton.Properties.Resources.Ball;
            this.arrow8_7.Location = new System.Drawing.Point(203, 186);
            this.arrow8_7.Name = "arrow8_7";
            this.arrow8_7.Size = new System.Drawing.Size(13, 14);
            this.arrow8_7.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.arrow8_7.TabIndex = 46;
            this.arrow8_7.TabStop = false;
            // 
            // arrow7_7
            // 
            this.arrow7_7.Image = global::_13052017_galton.Properties.Resources.Ball;
            this.arrow7_7.Location = new System.Drawing.Point(220, 169);
            this.arrow7_7.Name = "arrow7_7";
            this.arrow7_7.Size = new System.Drawing.Size(13, 14);
            this.arrow7_7.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.arrow7_7.TabIndex = 45;
            this.arrow7_7.TabStop = false;
            // 
            // arrow6_7
            // 
            this.arrow6_7.Image = global::_13052017_galton.Properties.Resources.Ball;
            this.arrow6_7.Location = new System.Drawing.Point(238, 152);
            this.arrow6_7.Name = "arrow6_7";
            this.arrow6_7.Size = new System.Drawing.Size(13, 14);
            this.arrow6_7.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.arrow6_7.TabIndex = 44;
            this.arrow6_7.TabStop = false;
            // 
            // arrow5_7
            // 
            this.arrow5_7.Image = global::_13052017_galton.Properties.Resources.Ball;
            this.arrow5_7.Location = new System.Drawing.Point(255, 135);
            this.arrow5_7.Name = "arrow5_7";
            this.arrow5_7.Size = new System.Drawing.Size(13, 14);
            this.arrow5_7.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.arrow5_7.TabIndex = 43;
            this.arrow5_7.TabStop = false;
            // 
            // arrow4_7
            // 
            this.arrow4_7.Image = global::_13052017_galton.Properties.Resources.Ball;
            this.arrow4_7.Location = new System.Drawing.Point(272, 119);
            this.arrow4_7.Name = "arrow4_7";
            this.arrow4_7.Size = new System.Drawing.Size(13, 14);
            this.arrow4_7.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.arrow4_7.TabIndex = 42;
            this.arrow4_7.TabStop = false;
            // 
            // arrow12_9
            // 
            this.arrow12_9.Image = global::_13052017_galton.Properties.Resources.Ball;
            this.arrow12_9.Location = new System.Drawing.Point(169, 256);
            this.arrow12_9.Name = "arrow12_9";
            this.arrow12_9.Size = new System.Drawing.Size(13, 14);
            this.arrow12_9.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.arrow12_9.TabIndex = 62;
            this.arrow12_9.TabStop = false;
            // 
            // arrow11_9
            // 
            this.arrow11_9.Image = global::_13052017_galton.Properties.Resources.Ball;
            this.arrow11_9.Location = new System.Drawing.Point(186, 237);
            this.arrow11_9.Name = "arrow11_9";
            this.arrow11_9.Size = new System.Drawing.Size(13, 14);
            this.arrow11_9.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.arrow11_9.TabIndex = 61;
            this.arrow11_9.TabStop = false;
            // 
            // arrow10_9
            // 
            this.arrow10_9.Image = global::_13052017_galton.Properties.Resources.Ball;
            this.arrow10_9.Location = new System.Drawing.Point(203, 220);
            this.arrow10_9.Name = "arrow10_9";
            this.arrow10_9.Size = new System.Drawing.Size(13, 14);
            this.arrow10_9.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.arrow10_9.TabIndex = 60;
            this.arrow10_9.TabStop = false;
            // 
            // arrow9_9
            // 
            this.arrow9_9.Image = global::_13052017_galton.Properties.Resources.Ball;
            this.arrow9_9.Location = new System.Drawing.Point(221, 204);
            this.arrow9_9.Name = "arrow9_9";
            this.arrow9_9.Size = new System.Drawing.Size(13, 14);
            this.arrow9_9.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.arrow9_9.TabIndex = 59;
            this.arrow9_9.TabStop = false;
            // 
            // arrow8_9
            // 
            this.arrow8_9.Image = global::_13052017_galton.Properties.Resources.Ball;
            this.arrow8_9.Location = new System.Drawing.Point(238, 187);
            this.arrow8_9.Name = "arrow8_9";
            this.arrow8_9.Size = new System.Drawing.Size(13, 14);
            this.arrow8_9.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.arrow8_9.TabIndex = 58;
            this.arrow8_9.TabStop = false;
            // 
            // arrow7_9
            // 
            this.arrow7_9.Image = global::_13052017_galton.Properties.Resources.Ball;
            this.arrow7_9.Location = new System.Drawing.Point(255, 170);
            this.arrow7_9.Name = "arrow7_9";
            this.arrow7_9.Size = new System.Drawing.Size(13, 14);
            this.arrow7_9.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.arrow7_9.TabIndex = 57;
            this.arrow7_9.TabStop = false;
            // 
            // arrow6_9
            // 
            this.arrow6_9.Image = global::_13052017_galton.Properties.Resources.Ball;
            this.arrow6_9.Location = new System.Drawing.Point(272, 152);
            this.arrow6_9.Name = "arrow6_9";
            this.arrow6_9.Size = new System.Drawing.Size(13, 14);
            this.arrow6_9.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.arrow6_9.TabIndex = 56;
            this.arrow6_9.TabStop = false;
            // 
            // arrow5_9
            // 
            this.arrow5_9.Image = global::_13052017_galton.Properties.Resources.Ball;
            this.arrow5_9.Location = new System.Drawing.Point(289, 135);
            this.arrow5_9.Name = "arrow5_9";
            this.arrow5_9.Size = new System.Drawing.Size(13, 14);
            this.arrow5_9.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.arrow5_9.TabIndex = 55;
            this.arrow5_9.TabStop = false;
            // 
            // arrow12_11
            // 
            this.arrow12_11.Image = global::_13052017_galton.Properties.Resources.Ball;
            this.arrow12_11.Location = new System.Drawing.Point(203, 257);
            this.arrow12_11.Name = "arrow12_11";
            this.arrow12_11.Size = new System.Drawing.Size(13, 14);
            this.arrow12_11.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.arrow12_11.TabIndex = 70;
            this.arrow12_11.TabStop = false;
            // 
            // arrow11_11
            // 
            this.arrow11_11.Image = global::_13052017_galton.Properties.Resources.Ball;
            this.arrow11_11.Location = new System.Drawing.Point(221, 238);
            this.arrow11_11.Name = "arrow11_11";
            this.arrow11_11.Size = new System.Drawing.Size(13, 14);
            this.arrow11_11.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.arrow11_11.TabIndex = 69;
            this.arrow11_11.TabStop = false;
            // 
            // arrow10_11
            // 
            this.arrow10_11.Image = global::_13052017_galton.Properties.Resources.Ball;
            this.arrow10_11.Location = new System.Drawing.Point(238, 220);
            this.arrow10_11.Name = "arrow10_11";
            this.arrow10_11.Size = new System.Drawing.Size(13, 14);
            this.arrow10_11.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.arrow10_11.TabIndex = 68;
            this.arrow10_11.TabStop = false;
            // 
            // arrow9_11
            // 
            this.arrow9_11.Image = global::_13052017_galton.Properties.Resources.Ball;
            this.arrow9_11.Location = new System.Drawing.Point(255, 204);
            this.arrow9_11.Name = "arrow9_11";
            this.arrow9_11.Size = new System.Drawing.Size(13, 14);
            this.arrow9_11.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.arrow9_11.TabIndex = 67;
            this.arrow9_11.TabStop = false;
            // 
            // arrow8_11
            // 
            this.arrow8_11.Image = global::_13052017_galton.Properties.Resources.Ball;
            this.arrow8_11.Location = new System.Drawing.Point(271, 187);
            this.arrow8_11.Name = "arrow8_11";
            this.arrow8_11.Size = new System.Drawing.Size(13, 14);
            this.arrow8_11.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.arrow8_11.TabIndex = 66;
            this.arrow8_11.TabStop = false;
            // 
            // arrow7_11
            // 
            this.arrow7_11.Image = global::_13052017_galton.Properties.Resources.Ball;
            this.arrow7_11.Location = new System.Drawing.Point(289, 170);
            this.arrow7_11.Name = "arrow7_11";
            this.arrow7_11.Size = new System.Drawing.Size(13, 14);
            this.arrow7_11.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.arrow7_11.TabIndex = 65;
            this.arrow7_11.TabStop = false;
            // 
            // arrow6_11
            // 
            this.arrow6_11.Image = global::_13052017_galton.Properties.Resources.Ball;
            this.arrow6_11.Location = new System.Drawing.Point(306, 152);
            this.arrow6_11.Name = "arrow6_11";
            this.arrow6_11.Size = new System.Drawing.Size(13, 14);
            this.arrow6_11.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.arrow6_11.TabIndex = 64;
            this.arrow6_11.TabStop = false;
            // 
            // arrow12_13
            // 
            this.arrow12_13.Image = global::_13052017_galton.Properties.Resources.Ball;
            this.arrow12_13.Location = new System.Drawing.Point(237, 258);
            this.arrow12_13.Name = "arrow12_13";
            this.arrow12_13.Size = new System.Drawing.Size(13, 14);
            this.arrow12_13.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.arrow12_13.TabIndex = 78;
            this.arrow12_13.TabStop = false;
            // 
            // arrow11_13
            // 
            this.arrow11_13.Image = global::_13052017_galton.Properties.Resources.Ball;
            this.arrow11_13.Location = new System.Drawing.Point(255, 238);
            this.arrow11_13.Name = "arrow11_13";
            this.arrow11_13.Size = new System.Drawing.Size(13, 14);
            this.arrow11_13.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.arrow11_13.TabIndex = 77;
            this.arrow11_13.TabStop = false;
            // 
            // arrow10_13
            // 
            this.arrow10_13.Image = global::_13052017_galton.Properties.Resources.Ball;
            this.arrow10_13.Location = new System.Drawing.Point(271, 221);
            this.arrow10_13.Name = "arrow10_13";
            this.arrow10_13.Size = new System.Drawing.Size(13, 14);
            this.arrow10_13.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.arrow10_13.TabIndex = 76;
            this.arrow10_13.TabStop = false;
            // 
            // arrow9_13
            // 
            this.arrow9_13.Image = global::_13052017_galton.Properties.Resources.Ball;
            this.arrow9_13.Location = new System.Drawing.Point(289, 204);
            this.arrow9_13.Name = "arrow9_13";
            this.arrow9_13.Size = new System.Drawing.Size(13, 14);
            this.arrow9_13.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.arrow9_13.TabIndex = 75;
            this.arrow9_13.TabStop = false;
            // 
            // arrow8_13
            // 
            this.arrow8_13.Image = global::_13052017_galton.Properties.Resources.Ball;
            this.arrow8_13.Location = new System.Drawing.Point(306, 187);
            this.arrow8_13.Name = "arrow8_13";
            this.arrow8_13.Size = new System.Drawing.Size(13, 14);
            this.arrow8_13.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.arrow8_13.TabIndex = 74;
            this.arrow8_13.TabStop = false;
            // 
            // arrow7_13
            // 
            this.arrow7_13.Image = global::_13052017_galton.Properties.Resources.Ball;
            this.arrow7_13.Location = new System.Drawing.Point(322, 170);
            this.arrow7_13.Name = "arrow7_13";
            this.arrow7_13.Size = new System.Drawing.Size(13, 14);
            this.arrow7_13.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.arrow7_13.TabIndex = 73;
            this.arrow7_13.TabStop = false;
            // 
            // arrow12_15
            // 
            this.arrow12_15.Image = global::_13052017_galton.Properties.Resources.Ball;
            this.arrow12_15.Location = new System.Drawing.Point(272, 257);
            this.arrow12_15.Name = "arrow12_15";
            this.arrow12_15.Size = new System.Drawing.Size(13, 14);
            this.arrow12_15.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.arrow12_15.TabIndex = 86;
            this.arrow12_15.TabStop = false;
            // 
            // arrow11_15
            // 
            this.arrow11_15.Image = global::_13052017_galton.Properties.Resources.Ball;
            this.arrow11_15.Location = new System.Drawing.Point(289, 238);
            this.arrow11_15.Name = "arrow11_15";
            this.arrow11_15.Size = new System.Drawing.Size(13, 14);
            this.arrow11_15.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.arrow11_15.TabIndex = 85;
            this.arrow11_15.TabStop = false;
            // 
            // arrow10_15
            // 
            this.arrow10_15.Image = global::_13052017_galton.Properties.Resources.Ball;
            this.arrow10_15.Location = new System.Drawing.Point(306, 220);
            this.arrow10_15.Name = "arrow10_15";
            this.arrow10_15.Size = new System.Drawing.Size(13, 14);
            this.arrow10_15.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.arrow10_15.TabIndex = 84;
            this.arrow10_15.TabStop = false;
            // 
            // arrow9_15
            // 
            this.arrow9_15.Image = global::_13052017_galton.Properties.Resources.Ball;
            this.arrow9_15.Location = new System.Drawing.Point(323, 203);
            this.arrow9_15.Name = "arrow9_15";
            this.arrow9_15.Size = new System.Drawing.Size(13, 14);
            this.arrow9_15.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.arrow9_15.TabIndex = 83;
            this.arrow9_15.TabStop = false;
            // 
            // arrow8_15
            // 
            this.arrow8_15.Image = global::_13052017_galton.Properties.Resources.Ball;
            this.arrow8_15.Location = new System.Drawing.Point(339, 188);
            this.arrow8_15.Name = "arrow8_15";
            this.arrow8_15.Size = new System.Drawing.Size(13, 14);
            this.arrow8_15.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.arrow8_15.TabIndex = 82;
            this.arrow8_15.TabStop = false;
            // 
            // arrow12_17
            // 
            this.arrow12_17.Image = global::_13052017_galton.Properties.Resources.Ball;
            this.arrow12_17.Location = new System.Drawing.Point(306, 257);
            this.arrow12_17.Name = "arrow12_17";
            this.arrow12_17.Size = new System.Drawing.Size(13, 14);
            this.arrow12_17.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.arrow12_17.TabIndex = 94;
            this.arrow12_17.TabStop = false;
            // 
            // arrow11_17
            // 
            this.arrow11_17.Image = global::_13052017_galton.Properties.Resources.Ball;
            this.arrow11_17.Location = new System.Drawing.Point(323, 237);
            this.arrow11_17.Name = "arrow11_17";
            this.arrow11_17.Size = new System.Drawing.Size(13, 14);
            this.arrow11_17.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.arrow11_17.TabIndex = 93;
            this.arrow11_17.TabStop = false;
            // 
            // arrow10_17
            // 
            this.arrow10_17.Image = global::_13052017_galton.Properties.Resources.Ball;
            this.arrow10_17.Location = new System.Drawing.Point(340, 220);
            this.arrow10_17.Name = "arrow10_17";
            this.arrow10_17.Size = new System.Drawing.Size(13, 14);
            this.arrow10_17.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.arrow10_17.TabIndex = 92;
            this.arrow10_17.TabStop = false;
            // 
            // arrow9_17
            // 
            this.arrow9_17.Image = global::_13052017_galton.Properties.Resources.Ball;
            this.arrow9_17.Location = new System.Drawing.Point(356, 203);
            this.arrow9_17.Name = "arrow9_17";
            this.arrow9_17.Size = new System.Drawing.Size(13, 14);
            this.arrow9_17.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.arrow9_17.TabIndex = 91;
            this.arrow9_17.TabStop = false;
            // 
            // arrow12_19
            // 
            this.arrow12_19.Image = global::_13052017_galton.Properties.Resources.Ball;
            this.arrow12_19.Location = new System.Drawing.Point(339, 256);
            this.arrow12_19.Name = "arrow12_19";
            this.arrow12_19.Size = new System.Drawing.Size(13, 14);
            this.arrow12_19.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.arrow12_19.TabIndex = 102;
            this.arrow12_19.TabStop = false;
            // 
            // arrow11_19
            // 
            this.arrow11_19.Image = global::_13052017_galton.Properties.Resources.Ball;
            this.arrow11_19.Location = new System.Drawing.Point(356, 237);
            this.arrow11_19.Name = "arrow11_19";
            this.arrow11_19.Size = new System.Drawing.Size(13, 14);
            this.arrow11_19.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.arrow11_19.TabIndex = 101;
            this.arrow11_19.TabStop = false;
            // 
            // arrow10_19
            // 
            this.arrow10_19.Image = global::_13052017_galton.Properties.Resources.Ball;
            this.arrow10_19.Location = new System.Drawing.Point(373, 220);
            this.arrow10_19.Name = "arrow10_19";
            this.arrow10_19.Size = new System.Drawing.Size(13, 14);
            this.arrow10_19.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.arrow10_19.TabIndex = 100;
            this.arrow10_19.TabStop = false;
            // 
            // arrow12_21
            // 
            this.arrow12_21.Image = global::_13052017_galton.Properties.Resources.Ball;
            this.arrow12_21.Location = new System.Drawing.Point(373, 256);
            this.arrow12_21.Name = "arrow12_21";
            this.arrow12_21.Size = new System.Drawing.Size(13, 14);
            this.arrow12_21.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.arrow12_21.TabIndex = 105;
            this.arrow12_21.TabStop = false;
            // 
            // arrow11_21
            // 
            this.arrow11_21.Image = global::_13052017_galton.Properties.Resources.Ball;
            this.arrow11_21.Location = new System.Drawing.Point(389, 237);
            this.arrow11_21.Name = "arrow11_21";
            this.arrow11_21.Size = new System.Drawing.Size(13, 14);
            this.arrow11_21.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.arrow11_21.TabIndex = 104;
            this.arrow11_21.TabStop = false;
            // 
            // arrow12_23
            // 
            this.arrow12_23.Image = global::_13052017_galton.Properties.Resources.Ball;
            this.arrow12_23.Location = new System.Drawing.Point(407, 256);
            this.arrow12_23.Name = "arrow12_23";
            this.arrow12_23.Size = new System.Drawing.Size(13, 14);
            this.arrow12_23.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.arrow12_23.TabIndex = 106;
            this.arrow12_23.TabStop = false;
            // 
            // arrow12_24
            // 
            this.arrow12_24.Image = global::_13052017_galton.Properties.Resources.Ball;
            this.arrow12_24.Location = new System.Drawing.Point(433, 255);
            this.arrow12_24.Name = "arrow12_24";
            this.arrow12_24.Size = new System.Drawing.Size(13, 14);
            this.arrow12_24.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.arrow12_24.TabIndex = 184;
            this.arrow12_24.TabStop = false;
            // 
            // arrow12_22
            // 
            this.arrow12_22.Image = global::_13052017_galton.Properties.Resources.Ball;
            this.arrow12_22.Location = new System.Drawing.Point(399, 256);
            this.arrow12_22.Name = "arrow12_22";
            this.arrow12_22.Size = new System.Drawing.Size(13, 14);
            this.arrow12_22.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.arrow12_22.TabIndex = 183;
            this.arrow12_22.TabStop = false;
            // 
            // arrow11_22
            // 
            this.arrow11_22.Image = global::_13052017_galton.Properties.Resources.Ball;
            this.arrow11_22.Location = new System.Drawing.Point(415, 237);
            this.arrow11_22.Name = "arrow11_22";
            this.arrow11_22.Size = new System.Drawing.Size(13, 14);
            this.arrow11_22.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.arrow11_22.TabIndex = 182;
            this.arrow11_22.TabStop = false;
            // 
            // arrow12_20
            // 
            this.arrow12_20.Image = global::_13052017_galton.Properties.Resources.Ball;
            this.arrow12_20.Location = new System.Drawing.Point(365, 256);
            this.arrow12_20.Name = "arrow12_20";
            this.arrow12_20.Size = new System.Drawing.Size(13, 14);
            this.arrow12_20.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.arrow12_20.TabIndex = 181;
            this.arrow12_20.TabStop = false;
            // 
            // arrow11_20
            // 
            this.arrow11_20.Image = global::_13052017_galton.Properties.Resources.Ball;
            this.arrow11_20.Location = new System.Drawing.Point(382, 237);
            this.arrow11_20.Name = "arrow11_20";
            this.arrow11_20.Size = new System.Drawing.Size(13, 14);
            this.arrow11_20.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.arrow11_20.TabIndex = 180;
            this.arrow11_20.TabStop = false;
            // 
            // arrow10_20
            // 
            this.arrow10_20.Image = global::_13052017_galton.Properties.Resources.Ball;
            this.arrow10_20.Location = new System.Drawing.Point(399, 220);
            this.arrow10_20.Name = "arrow10_20";
            this.arrow10_20.Size = new System.Drawing.Size(13, 14);
            this.arrow10_20.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.arrow10_20.TabIndex = 179;
            this.arrow10_20.TabStop = false;
            // 
            // arrow12_18
            // 
            this.arrow12_18.Image = global::_13052017_galton.Properties.Resources.Ball;
            this.arrow12_18.Location = new System.Drawing.Point(332, 256);
            this.arrow12_18.Name = "arrow12_18";
            this.arrow12_18.Size = new System.Drawing.Size(13, 14);
            this.arrow12_18.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.arrow12_18.TabIndex = 178;
            this.arrow12_18.TabStop = false;
            // 
            // arrow11_18
            // 
            this.arrow11_18.Image = global::_13052017_galton.Properties.Resources.Ball;
            this.arrow11_18.Location = new System.Drawing.Point(349, 237);
            this.arrow11_18.Name = "arrow11_18";
            this.arrow11_18.Size = new System.Drawing.Size(13, 14);
            this.arrow11_18.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.arrow11_18.TabIndex = 177;
            this.arrow11_18.TabStop = false;
            // 
            // arrow10_18
            // 
            this.arrow10_18.Image = global::_13052017_galton.Properties.Resources.Ball;
            this.arrow10_18.Location = new System.Drawing.Point(366, 220);
            this.arrow10_18.Name = "arrow10_18";
            this.arrow10_18.Size = new System.Drawing.Size(13, 14);
            this.arrow10_18.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.arrow10_18.TabIndex = 176;
            this.arrow10_18.TabStop = false;
            // 
            // arrow9_18
            // 
            this.arrow9_18.Image = global::_13052017_galton.Properties.Resources.Ball;
            this.arrow9_18.Location = new System.Drawing.Point(382, 203);
            this.arrow9_18.Name = "arrow9_18";
            this.arrow9_18.Size = new System.Drawing.Size(13, 14);
            this.arrow9_18.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.arrow9_18.TabIndex = 175;
            this.arrow9_18.TabStop = false;
            // 
            // arrow12_16
            // 
            this.arrow12_16.Image = global::_13052017_galton.Properties.Resources.Ball;
            this.arrow12_16.Location = new System.Drawing.Point(298, 257);
            this.arrow12_16.Name = "arrow12_16";
            this.arrow12_16.Size = new System.Drawing.Size(13, 14);
            this.arrow12_16.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.arrow12_16.TabIndex = 174;
            this.arrow12_16.TabStop = false;
            // 
            // arrow11_16
            // 
            this.arrow11_16.Image = global::_13052017_galton.Properties.Resources.Ball;
            this.arrow11_16.Location = new System.Drawing.Point(316, 237);
            this.arrow11_16.Name = "arrow11_16";
            this.arrow11_16.Size = new System.Drawing.Size(13, 14);
            this.arrow11_16.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.arrow11_16.TabIndex = 173;
            this.arrow11_16.TabStop = false;
            // 
            // arrow10_16
            // 
            this.arrow10_16.Image = global::_13052017_galton.Properties.Resources.Ball;
            this.arrow10_16.Location = new System.Drawing.Point(332, 220);
            this.arrow10_16.Name = "arrow10_16";
            this.arrow10_16.Size = new System.Drawing.Size(13, 14);
            this.arrow10_16.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.arrow10_16.TabIndex = 172;
            this.arrow10_16.TabStop = false;
            // 
            // arrow9_16
            // 
            this.arrow9_16.Image = global::_13052017_galton.Properties.Resources.Ball;
            this.arrow9_16.Location = new System.Drawing.Point(349, 203);
            this.arrow9_16.Name = "arrow9_16";
            this.arrow9_16.Size = new System.Drawing.Size(13, 14);
            this.arrow9_16.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.arrow9_16.TabIndex = 171;
            this.arrow9_16.TabStop = false;
            // 
            // arrow8_16
            // 
            this.arrow8_16.Image = global::_13052017_galton.Properties.Resources.Ball;
            this.arrow8_16.Location = new System.Drawing.Point(365, 186);
            this.arrow8_16.Name = "arrow8_16";
            this.arrow8_16.Size = new System.Drawing.Size(13, 14);
            this.arrow8_16.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.arrow8_16.TabIndex = 170;
            this.arrow8_16.TabStop = false;
            // 
            // arrow12_14
            // 
            this.arrow12_14.Image = global::_13052017_galton.Properties.Resources.Ball;
            this.arrow12_14.Location = new System.Drawing.Point(263, 257);
            this.arrow12_14.Name = "arrow12_14";
            this.arrow12_14.Size = new System.Drawing.Size(13, 14);
            this.arrow12_14.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.arrow12_14.TabIndex = 169;
            this.arrow12_14.TabStop = false;
            // 
            // arrow11_14
            // 
            this.arrow11_14.Image = global::_13052017_galton.Properties.Resources.Ball;
            this.arrow11_14.Location = new System.Drawing.Point(281, 238);
            this.arrow11_14.Name = "arrow11_14";
            this.arrow11_14.Size = new System.Drawing.Size(13, 14);
            this.arrow11_14.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.arrow11_14.TabIndex = 168;
            this.arrow11_14.TabStop = false;
            // 
            // arrow10_14
            // 
            this.arrow10_14.Image = global::_13052017_galton.Properties.Resources.Ball;
            this.arrow10_14.Location = new System.Drawing.Point(297, 220);
            this.arrow10_14.Name = "arrow10_14";
            this.arrow10_14.Size = new System.Drawing.Size(13, 14);
            this.arrow10_14.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.arrow10_14.TabIndex = 167;
            this.arrow10_14.TabStop = false;
            // 
            // arrow9_14
            // 
            this.arrow9_14.Image = global::_13052017_galton.Properties.Resources.Ball;
            this.arrow9_14.Location = new System.Drawing.Point(315, 203);
            this.arrow9_14.Name = "arrow9_14";
            this.arrow9_14.Size = new System.Drawing.Size(13, 14);
            this.arrow9_14.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.arrow9_14.TabIndex = 166;
            this.arrow9_14.TabStop = false;
            // 
            // arrow8_14
            // 
            this.arrow8_14.Image = global::_13052017_galton.Properties.Resources.Ball;
            this.arrow8_14.Location = new System.Drawing.Point(332, 186);
            this.arrow8_14.Name = "arrow8_14";
            this.arrow8_14.Size = new System.Drawing.Size(13, 14);
            this.arrow8_14.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.arrow8_14.TabIndex = 165;
            this.arrow8_14.TabStop = false;
            // 
            // arrow7_14
            // 
            this.arrow7_14.Image = global::_13052017_galton.Properties.Resources.Ball;
            this.arrow7_14.Location = new System.Drawing.Point(348, 168);
            this.arrow7_14.Name = "arrow7_14";
            this.arrow7_14.Size = new System.Drawing.Size(13, 14);
            this.arrow7_14.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.arrow7_14.TabIndex = 164;
            this.arrow7_14.TabStop = false;
            // 
            // arrow12_12
            // 
            this.arrow12_12.Image = global::_13052017_galton.Properties.Resources.Ball;
            this.arrow12_12.Location = new System.Drawing.Point(229, 258);
            this.arrow12_12.Name = "arrow12_12";
            this.arrow12_12.Size = new System.Drawing.Size(13, 14);
            this.arrow12_12.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.arrow12_12.TabIndex = 163;
            this.arrow12_12.TabStop = false;
            // 
            // arrow11_12
            // 
            this.arrow11_12.Image = global::_13052017_galton.Properties.Resources.Ball;
            this.arrow11_12.Location = new System.Drawing.Point(247, 238);
            this.arrow11_12.Name = "arrow11_12";
            this.arrow11_12.Size = new System.Drawing.Size(13, 14);
            this.arrow11_12.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.arrow11_12.TabIndex = 162;
            this.arrow11_12.TabStop = false;
            // 
            // arrow10_12
            // 
            this.arrow10_12.Image = global::_13052017_galton.Properties.Resources.Ball;
            this.arrow10_12.Location = new System.Drawing.Point(264, 221);
            this.arrow10_12.Name = "arrow10_12";
            this.arrow10_12.Size = new System.Drawing.Size(13, 14);
            this.arrow10_12.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.arrow10_12.TabIndex = 161;
            this.arrow10_12.TabStop = false;
            // 
            // arrow9_12
            // 
            this.arrow9_12.Image = global::_13052017_galton.Properties.Resources.Ball;
            this.arrow9_12.Location = new System.Drawing.Point(281, 204);
            this.arrow9_12.Name = "arrow9_12";
            this.arrow9_12.Size = new System.Drawing.Size(13, 14);
            this.arrow9_12.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.arrow9_12.TabIndex = 160;
            this.arrow9_12.TabStop = false;
            // 
            // arrow8_12
            // 
            this.arrow8_12.Image = global::_13052017_galton.Properties.Resources.Ball;
            this.arrow8_12.Location = new System.Drawing.Point(297, 187);
            this.arrow8_12.Name = "arrow8_12";
            this.arrow8_12.Size = new System.Drawing.Size(13, 14);
            this.arrow8_12.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.arrow8_12.TabIndex = 159;
            this.arrow8_12.TabStop = false;
            // 
            // arrow7_12
            // 
            this.arrow7_12.Image = global::_13052017_galton.Properties.Resources.Ball;
            this.arrow7_12.Location = new System.Drawing.Point(315, 170);
            this.arrow7_12.Name = "arrow7_12";
            this.arrow7_12.Size = new System.Drawing.Size(13, 14);
            this.arrow7_12.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.arrow7_12.TabIndex = 158;
            this.arrow7_12.TabStop = false;
            // 
            // arrow6_12
            // 
            this.arrow6_12.Image = global::_13052017_galton.Properties.Resources.Ball;
            this.arrow6_12.Location = new System.Drawing.Point(332, 152);
            this.arrow6_12.Name = "arrow6_12";
            this.arrow6_12.Size = new System.Drawing.Size(13, 14);
            this.arrow6_12.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.arrow6_12.TabIndex = 157;
            this.arrow6_12.TabStop = false;
            // 
            // arrow12_10
            // 
            this.arrow12_10.Image = global::_13052017_galton.Properties.Resources.Ball;
            this.arrow12_10.Location = new System.Drawing.Point(195, 257);
            this.arrow12_10.Name = "arrow12_10";
            this.arrow12_10.Size = new System.Drawing.Size(13, 14);
            this.arrow12_10.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.arrow12_10.TabIndex = 156;
            this.arrow12_10.TabStop = false;
            // 
            // arrow11_10
            // 
            this.arrow11_10.Image = global::_13052017_galton.Properties.Resources.Ball;
            this.arrow11_10.Location = new System.Drawing.Point(212, 238);
            this.arrow11_10.Name = "arrow11_10";
            this.arrow11_10.Size = new System.Drawing.Size(13, 14);
            this.arrow11_10.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.arrow11_10.TabIndex = 155;
            this.arrow11_10.TabStop = false;
            // 
            // arrow10_10
            // 
            this.arrow10_10.Image = global::_13052017_galton.Properties.Resources.Ball;
            this.arrow10_10.Location = new System.Drawing.Point(229, 220);
            this.arrow10_10.Name = "arrow10_10";
            this.arrow10_10.Size = new System.Drawing.Size(13, 14);
            this.arrow10_10.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.arrow10_10.TabIndex = 154;
            this.arrow10_10.TabStop = false;
            // 
            // arrow9_10
            // 
            this.arrow9_10.Image = global::_13052017_galton.Properties.Resources.Ball;
            this.arrow9_10.Location = new System.Drawing.Point(247, 204);
            this.arrow9_10.Name = "arrow9_10";
            this.arrow9_10.Size = new System.Drawing.Size(13, 14);
            this.arrow9_10.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.arrow9_10.TabIndex = 153;
            this.arrow9_10.TabStop = false;
            // 
            // arrow8_10
            // 
            this.arrow8_10.Image = global::_13052017_galton.Properties.Resources.Ball;
            this.arrow8_10.Location = new System.Drawing.Point(264, 187);
            this.arrow8_10.Name = "arrow8_10";
            this.arrow8_10.Size = new System.Drawing.Size(13, 14);
            this.arrow8_10.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.arrow8_10.TabIndex = 152;
            this.arrow8_10.TabStop = false;
            // 
            // arrow7_10
            // 
            this.arrow7_10.Image = global::_13052017_galton.Properties.Resources.Ball;
            this.arrow7_10.Location = new System.Drawing.Point(281, 170);
            this.arrow7_10.Name = "arrow7_10";
            this.arrow7_10.Size = new System.Drawing.Size(13, 14);
            this.arrow7_10.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.arrow7_10.TabIndex = 151;
            this.arrow7_10.TabStop = false;
            // 
            // arrow6_10
            // 
            this.arrow6_10.Image = global::_13052017_galton.Properties.Resources.Ball;
            this.arrow6_10.Location = new System.Drawing.Point(298, 152);
            this.arrow6_10.Name = "arrow6_10";
            this.arrow6_10.Size = new System.Drawing.Size(13, 14);
            this.arrow6_10.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.arrow6_10.TabIndex = 150;
            this.arrow6_10.TabStop = false;
            // 
            // arrow5_10
            // 
            this.arrow5_10.Image = global::_13052017_galton.Properties.Resources.Ball;
            this.arrow5_10.Location = new System.Drawing.Point(315, 135);
            this.arrow5_10.Name = "arrow5_10";
            this.arrow5_10.Size = new System.Drawing.Size(13, 14);
            this.arrow5_10.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.arrow5_10.TabIndex = 149;
            this.arrow5_10.TabStop = false;
            // 
            // arrow12_8
            // 
            this.arrow12_8.Image = global::_13052017_galton.Properties.Resources.Ball;
            this.arrow12_8.Location = new System.Drawing.Point(161, 256);
            this.arrow12_8.Name = "arrow12_8";
            this.arrow12_8.Size = new System.Drawing.Size(13, 14);
            this.arrow12_8.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.arrow12_8.TabIndex = 148;
            this.arrow12_8.TabStop = false;
            // 
            // arrow11_8
            // 
            this.arrow11_8.Image = global::_13052017_galton.Properties.Resources.Ball;
            this.arrow11_8.Location = new System.Drawing.Point(178, 237);
            this.arrow11_8.Name = "arrow11_8";
            this.arrow11_8.Size = new System.Drawing.Size(13, 14);
            this.arrow11_8.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.arrow11_8.TabIndex = 147;
            this.arrow11_8.TabStop = false;
            // 
            // arrow10_8
            // 
            this.arrow10_8.Image = global::_13052017_galton.Properties.Resources.Ball;
            this.arrow10_8.Location = new System.Drawing.Point(195, 220);
            this.arrow10_8.Name = "arrow10_8";
            this.arrow10_8.Size = new System.Drawing.Size(13, 14);
            this.arrow10_8.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.arrow10_8.TabIndex = 146;
            this.arrow10_8.TabStop = false;
            // 
            // arrow9_8
            // 
            this.arrow9_8.Image = global::_13052017_galton.Properties.Resources.Ball;
            this.arrow9_8.Location = new System.Drawing.Point(212, 204);
            this.arrow9_8.Name = "arrow9_8";
            this.arrow9_8.Size = new System.Drawing.Size(13, 14);
            this.arrow9_8.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.arrow9_8.TabIndex = 145;
            this.arrow9_8.TabStop = false;
            // 
            // arrow8_8
            // 
            this.arrow8_8.Image = global::_13052017_galton.Properties.Resources.Ball;
            this.arrow8_8.Location = new System.Drawing.Point(229, 187);
            this.arrow8_8.Name = "arrow8_8";
            this.arrow8_8.Size = new System.Drawing.Size(13, 14);
            this.arrow8_8.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.arrow8_8.TabIndex = 144;
            this.arrow8_8.TabStop = false;
            // 
            // arrow7_8
            // 
            this.arrow7_8.Image = global::_13052017_galton.Properties.Resources.Ball;
            this.arrow7_8.Location = new System.Drawing.Point(246, 170);
            this.arrow7_8.Name = "arrow7_8";
            this.arrow7_8.Size = new System.Drawing.Size(13, 14);
            this.arrow7_8.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.arrow7_8.TabIndex = 143;
            this.arrow7_8.TabStop = false;
            // 
            // arrow6_8
            // 
            this.arrow6_8.Image = global::_13052017_galton.Properties.Resources.Ball;
            this.arrow6_8.Location = new System.Drawing.Point(264, 152);
            this.arrow6_8.Name = "arrow6_8";
            this.arrow6_8.Size = new System.Drawing.Size(13, 14);
            this.arrow6_8.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.arrow6_8.TabIndex = 142;
            this.arrow6_8.TabStop = false;
            // 
            // arrow5_8
            // 
            this.arrow5_8.Image = global::_13052017_galton.Properties.Resources.Ball;
            this.arrow5_8.Location = new System.Drawing.Point(281, 135);
            this.arrow5_8.Name = "arrow5_8";
            this.arrow5_8.Size = new System.Drawing.Size(13, 14);
            this.arrow5_8.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.arrow5_8.TabIndex = 141;
            this.arrow5_8.TabStop = false;
            // 
            // arrow4_8
            // 
            this.arrow4_8.Image = global::_13052017_galton.Properties.Resources.Ball;
            this.arrow4_8.Location = new System.Drawing.Point(298, 119);
            this.arrow4_8.Name = "arrow4_8";
            this.arrow4_8.Size = new System.Drawing.Size(13, 14);
            this.arrow4_8.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.arrow4_8.TabIndex = 140;
            this.arrow4_8.TabStop = false;
            // 
            // arrow12_6
            // 
            this.arrow12_6.Image = global::_13052017_galton.Properties.Resources.Ball;
            this.arrow12_6.Location = new System.Drawing.Point(127, 257);
            this.arrow12_6.Name = "arrow12_6";
            this.arrow12_6.Size = new System.Drawing.Size(13, 14);
            this.arrow12_6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.arrow12_6.TabIndex = 139;
            this.arrow12_6.TabStop = false;
            // 
            // arrow11_6
            // 
            this.arrow11_6.Image = global::_13052017_galton.Properties.Resources.Ball;
            this.arrow11_6.Location = new System.Drawing.Point(144, 237);
            this.arrow11_6.Name = "arrow11_6";
            this.arrow11_6.Size = new System.Drawing.Size(13, 14);
            this.arrow11_6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.arrow11_6.TabIndex = 138;
            this.arrow11_6.TabStop = false;
            // 
            // arrow10_6
            // 
            this.arrow10_6.Image = global::_13052017_galton.Properties.Resources.Ball;
            this.arrow10_6.Location = new System.Drawing.Point(161, 221);
            this.arrow10_6.Name = "arrow10_6";
            this.arrow10_6.Size = new System.Drawing.Size(13, 14);
            this.arrow10_6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.arrow10_6.TabIndex = 137;
            this.arrow10_6.TabStop = false;
            // 
            // arrow9_6
            // 
            this.arrow9_6.Image = global::_13052017_galton.Properties.Resources.Ball;
            this.arrow9_6.Location = new System.Drawing.Point(178, 203);
            this.arrow9_6.Name = "arrow9_6";
            this.arrow9_6.Size = new System.Drawing.Size(13, 14);
            this.arrow9_6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.arrow9_6.TabIndex = 136;
            this.arrow9_6.TabStop = false;
            // 
            // arrow8_6
            // 
            this.arrow8_6.Image = global::_13052017_galton.Properties.Resources.Ball;
            this.arrow8_6.Location = new System.Drawing.Point(195, 186);
            this.arrow8_6.Name = "arrow8_6";
            this.arrow8_6.Size = new System.Drawing.Size(13, 14);
            this.arrow8_6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.arrow8_6.TabIndex = 135;
            this.arrow8_6.TabStop = false;
            // 
            // arrow7_6
            // 
            this.arrow7_6.Image = global::_13052017_galton.Properties.Resources.Ball;
            this.arrow7_6.Location = new System.Drawing.Point(212, 169);
            this.arrow7_6.Name = "arrow7_6";
            this.arrow7_6.Size = new System.Drawing.Size(13, 14);
            this.arrow7_6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.arrow7_6.TabIndex = 134;
            this.arrow7_6.TabStop = false;
            // 
            // arrow6_6
            // 
            this.arrow6_6.Image = global::_13052017_galton.Properties.Resources.Ball;
            this.arrow6_6.Location = new System.Drawing.Point(228, 152);
            this.arrow6_6.Name = "arrow6_6";
            this.arrow6_6.Size = new System.Drawing.Size(13, 14);
            this.arrow6_6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.arrow6_6.TabIndex = 133;
            this.arrow6_6.TabStop = false;
            // 
            // arrow5_6
            // 
            this.arrow5_6.Image = global::_13052017_galton.Properties.Resources.Ball;
            this.arrow5_6.Location = new System.Drawing.Point(246, 135);
            this.arrow5_6.Name = "arrow5_6";
            this.arrow5_6.Size = new System.Drawing.Size(13, 14);
            this.arrow5_6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.arrow5_6.TabIndex = 132;
            this.arrow5_6.TabStop = false;
            // 
            // arrow4_6
            // 
            this.arrow4_6.Image = global::_13052017_galton.Properties.Resources.Ball;
            this.arrow4_6.Location = new System.Drawing.Point(264, 119);
            this.arrow4_6.Name = "arrow4_6";
            this.arrow4_6.Size = new System.Drawing.Size(13, 14);
            this.arrow4_6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.arrow4_6.TabIndex = 131;
            this.arrow4_6.TabStop = false;
            // 
            // arrow3_6
            // 
            this.arrow3_6.Image = global::_13052017_galton.Properties.Resources.Ball;
            this.arrow3_6.Location = new System.Drawing.Point(281, 102);
            this.arrow3_6.Name = "arrow3_6";
            this.arrow3_6.Size = new System.Drawing.Size(13, 14);
            this.arrow3_6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.arrow3_6.TabIndex = 130;
            this.arrow3_6.TabStop = false;
            // 
            // arrow12_4
            // 
            this.arrow12_4.Image = global::_13052017_galton.Properties.Resources.Ball;
            this.arrow12_4.Location = new System.Drawing.Point(94, 257);
            this.arrow12_4.Name = "arrow12_4";
            this.arrow12_4.Size = new System.Drawing.Size(13, 14);
            this.arrow12_4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.arrow12_4.TabIndex = 129;
            this.arrow12_4.TabStop = false;
            // 
            // arrow11_4
            // 
            this.arrow11_4.Image = global::_13052017_galton.Properties.Resources.Ball;
            this.arrow11_4.Location = new System.Drawing.Point(111, 237);
            this.arrow11_4.Name = "arrow11_4";
            this.arrow11_4.Size = new System.Drawing.Size(13, 14);
            this.arrow11_4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.arrow11_4.TabIndex = 128;
            this.arrow11_4.TabStop = false;
            // 
            // arrow10_4
            // 
            this.arrow10_4.Image = global::_13052017_galton.Properties.Resources.Ball;
            this.arrow10_4.Location = new System.Drawing.Point(128, 220);
            this.arrow10_4.Name = "arrow10_4";
            this.arrow10_4.Size = new System.Drawing.Size(13, 14);
            this.arrow10_4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.arrow10_4.TabIndex = 127;
            this.arrow10_4.TabStop = false;
            // 
            // arrow9_4
            // 
            this.arrow9_4.Image = global::_13052017_galton.Properties.Resources.Ball;
            this.arrow9_4.Location = new System.Drawing.Point(145, 203);
            this.arrow9_4.Name = "arrow9_4";
            this.arrow9_4.Size = new System.Drawing.Size(13, 14);
            this.arrow9_4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.arrow9_4.TabIndex = 126;
            this.arrow9_4.TabStop = false;
            // 
            // arrow8_4
            // 
            this.arrow8_4.Image = global::_13052017_galton.Properties.Resources.Ball;
            this.arrow8_4.Location = new System.Drawing.Point(161, 186);
            this.arrow8_4.Name = "arrow8_4";
            this.arrow8_4.Size = new System.Drawing.Size(13, 14);
            this.arrow8_4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.arrow8_4.TabIndex = 125;
            this.arrow8_4.TabStop = false;
            // 
            // arrow7_4
            // 
            this.arrow7_4.Image = global::_13052017_galton.Properties.Resources.Ball;
            this.arrow7_4.Location = new System.Drawing.Point(177, 169);
            this.arrow7_4.Name = "arrow7_4";
            this.arrow7_4.Size = new System.Drawing.Size(13, 14);
            this.arrow7_4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.arrow7_4.TabIndex = 124;
            this.arrow7_4.TabStop = false;
            // 
            // arrow6_4
            // 
            this.arrow6_4.Image = global::_13052017_galton.Properties.Resources.Ball;
            this.arrow6_4.Location = new System.Drawing.Point(195, 152);
            this.arrow6_4.Name = "arrow6_4";
            this.arrow6_4.Size = new System.Drawing.Size(13, 14);
            this.arrow6_4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.arrow6_4.TabIndex = 123;
            this.arrow6_4.TabStop = false;
            // 
            // arrow5_4
            // 
            this.arrow5_4.Image = global::_13052017_galton.Properties.Resources.Ball;
            this.arrow5_4.Location = new System.Drawing.Point(212, 135);
            this.arrow5_4.Name = "arrow5_4";
            this.arrow5_4.Size = new System.Drawing.Size(13, 14);
            this.arrow5_4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.arrow5_4.TabIndex = 122;
            this.arrow5_4.TabStop = false;
            // 
            // arrow4_4
            // 
            this.arrow4_4.Image = global::_13052017_galton.Properties.Resources.Ball;
            this.arrow4_4.Location = new System.Drawing.Point(230, 118);
            this.arrow4_4.Name = "arrow4_4";
            this.arrow4_4.Size = new System.Drawing.Size(13, 14);
            this.arrow4_4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.arrow4_4.TabIndex = 121;
            this.arrow4_4.TabStop = false;
            // 
            // arrow3_4
            // 
            this.arrow3_4.Image = global::_13052017_galton.Properties.Resources.Ball;
            this.arrow3_4.Location = new System.Drawing.Point(246, 103);
            this.arrow3_4.Name = "arrow3_4";
            this.arrow3_4.Size = new System.Drawing.Size(13, 14);
            this.arrow3_4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.arrow3_4.TabIndex = 120;
            this.arrow3_4.TabStop = false;
            // 
            // arrow2_4
            // 
            this.arrow2_4.Image = global::_13052017_galton.Properties.Resources.Ball;
            this.arrow2_4.Location = new System.Drawing.Point(263, 86);
            this.arrow2_4.Name = "arrow2_4";
            this.arrow2_4.Size = new System.Drawing.Size(13, 14);
            this.arrow2_4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.arrow2_4.TabIndex = 119;
            this.arrow2_4.TabStop = false;
            // 
            // arrow12_2
            // 
            this.arrow12_2.Image = global::_13052017_galton.Properties.Resources.Ball;
            this.arrow12_2.Location = new System.Drawing.Point(60, 257);
            this.arrow12_2.Name = "arrow12_2";
            this.arrow12_2.Size = new System.Drawing.Size(13, 14);
            this.arrow12_2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.arrow12_2.TabIndex = 118;
            this.arrow12_2.TabStop = false;
            // 
            // arrow11_2
            // 
            this.arrow11_2.Image = global::_13052017_galton.Properties.Resources.Ball;
            this.arrow11_2.Location = new System.Drawing.Point(77, 237);
            this.arrow11_2.Name = "arrow11_2";
            this.arrow11_2.Size = new System.Drawing.Size(13, 14);
            this.arrow11_2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.arrow11_2.TabIndex = 117;
            this.arrow11_2.TabStop = false;
            // 
            // arrow10_2
            // 
            this.arrow10_2.Image = global::_13052017_galton.Properties.Resources.Ball;
            this.arrow10_2.Location = new System.Drawing.Point(94, 221);
            this.arrow10_2.Name = "arrow10_2";
            this.arrow10_2.Size = new System.Drawing.Size(13, 14);
            this.arrow10_2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.arrow10_2.TabIndex = 116;
            this.arrow10_2.TabStop = false;
            // 
            // arrow9_2
            // 
            this.arrow9_2.Image = global::_13052017_galton.Properties.Resources.Ball;
            this.arrow9_2.Location = new System.Drawing.Point(111, 203);
            this.arrow9_2.Name = "arrow9_2";
            this.arrow9_2.Size = new System.Drawing.Size(13, 14);
            this.arrow9_2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.arrow9_2.TabIndex = 115;
            this.arrow9_2.TabStop = false;
            // 
            // arrow8_2
            // 
            this.arrow8_2.Image = global::_13052017_galton.Properties.Resources.Ball;
            this.arrow8_2.Location = new System.Drawing.Point(128, 185);
            this.arrow8_2.Name = "arrow8_2";
            this.arrow8_2.Size = new System.Drawing.Size(13, 14);
            this.arrow8_2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.arrow8_2.TabIndex = 114;
            this.arrow8_2.TabStop = false;
            // 
            // arrow7_2
            // 
            this.arrow7_2.Image = global::_13052017_galton.Properties.Resources.Ball;
            this.arrow7_2.Location = new System.Drawing.Point(145, 170);
            this.arrow7_2.Name = "arrow7_2";
            this.arrow7_2.Size = new System.Drawing.Size(13, 14);
            this.arrow7_2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.arrow7_2.TabIndex = 113;
            this.arrow7_2.TabStop = false;
            // 
            // arrow6_2
            // 
            this.arrow6_2.Image = global::_13052017_galton.Properties.Resources.Ball;
            this.arrow6_2.Location = new System.Drawing.Point(161, 153);
            this.arrow6_2.Name = "arrow6_2";
            this.arrow6_2.Size = new System.Drawing.Size(13, 14);
            this.arrow6_2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.arrow6_2.TabIndex = 112;
            this.arrow6_2.TabStop = false;
            // 
            // arrow5_2
            // 
            this.arrow5_2.Image = global::_13052017_galton.Properties.Resources.Ball;
            this.arrow5_2.Location = new System.Drawing.Point(177, 135);
            this.arrow5_2.Name = "arrow5_2";
            this.arrow5_2.Size = new System.Drawing.Size(13, 14);
            this.arrow5_2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.arrow5_2.TabIndex = 111;
            this.arrow5_2.TabStop = false;
            // 
            // arrow4_2
            // 
            this.arrow4_2.Image = global::_13052017_galton.Properties.Resources.Ball;
            this.arrow4_2.Location = new System.Drawing.Point(195, 118);
            this.arrow4_2.Name = "arrow4_2";
            this.arrow4_2.Size = new System.Drawing.Size(13, 14);
            this.arrow4_2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.arrow4_2.TabIndex = 110;
            this.arrow4_2.TabStop = false;
            // 
            // arrow3_2
            // 
            this.arrow3_2.Image = global::_13052017_galton.Properties.Resources.Ball;
            this.arrow3_2.Location = new System.Drawing.Point(211, 103);
            this.arrow3_2.Name = "arrow3_2";
            this.arrow3_2.Size = new System.Drawing.Size(13, 14);
            this.arrow3_2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.arrow3_2.TabIndex = 109;
            this.arrow3_2.TabStop = false;
            // 
            // arrow2_2
            // 
            this.arrow2_2.Image = global::_13052017_galton.Properties.Resources.Ball;
            this.arrow2_2.Location = new System.Drawing.Point(228, 86);
            this.arrow2_2.Name = "arrow2_2";
            this.arrow2_2.Size = new System.Drawing.Size(13, 14);
            this.arrow2_2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.arrow2_2.TabIndex = 108;
            this.arrow2_2.TabStop = false;
            // 
            // arrow1_2
            // 
            this.arrow1_2.Image = global::_13052017_galton.Properties.Resources.Ball;
            this.arrow1_2.Location = new System.Drawing.Point(250, 66);
            this.arrow1_2.Name = "arrow1_2";
            this.arrow1_2.Size = new System.Drawing.Size(13, 14);
            this.arrow1_2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.arrow1_2.TabIndex = 107;
            this.arrow1_2.TabStop = false;
            // 
            // ball1
            // 
            this.ball1.Image = global::_13052017_galton.Properties.Resources.Ball;
            this.ball1.Location = new System.Drawing.Point(33, 276);
            this.ball1.Name = "ball1";
            this.ball1.Size = new System.Drawing.Size(13, 14);
            this.ball1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.ball1.TabIndex = 185;
            this.ball1.TabStop = false;
            // 
            // ball2
            // 
            this.ball2.Image = global::_13052017_galton.Properties.Resources.Ball;
            this.ball2.Location = new System.Drawing.Point(66, 276);
            this.ball2.Name = "ball2";
            this.ball2.Size = new System.Drawing.Size(13, 14);
            this.ball2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.ball2.TabIndex = 186;
            this.ball2.TabStop = false;
            // 
            // ball3
            // 
            this.ball3.Image = global::_13052017_galton.Properties.Resources.Ball;
            this.ball3.Location = new System.Drawing.Point(100, 276);
            this.ball3.Name = "ball3";
            this.ball3.Size = new System.Drawing.Size(13, 14);
            this.ball3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.ball3.TabIndex = 187;
            this.ball3.TabStop = false;
            // 
            // ball4
            // 
            this.ball4.Image = global::_13052017_galton.Properties.Resources.Ball;
            this.ball4.Location = new System.Drawing.Point(132, 276);
            this.ball4.Name = "ball4";
            this.ball4.Size = new System.Drawing.Size(13, 14);
            this.ball4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.ball4.TabIndex = 188;
            this.ball4.TabStop = false;
            // 
            // ball5
            // 
            this.ball5.Image = global::_13052017_galton.Properties.Resources.Ball;
            this.ball5.Location = new System.Drawing.Point(167, 276);
            this.ball5.Name = "ball5";
            this.ball5.Size = new System.Drawing.Size(13, 14);
            this.ball5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.ball5.TabIndex = 189;
            this.ball5.TabStop = false;
            // 
            // ball6
            // 
            this.ball6.Image = global::_13052017_galton.Properties.Resources.Ball;
            this.ball6.Location = new System.Drawing.Point(199, 276);
            this.ball6.Name = "ball6";
            this.ball6.Size = new System.Drawing.Size(13, 14);
            this.ball6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.ball6.TabIndex = 190;
            this.ball6.TabStop = false;
            // 
            // ball7
            // 
            this.ball7.Image = global::_13052017_galton.Properties.Resources.Ball;
            this.ball7.Location = new System.Drawing.Point(234, 277);
            this.ball7.Name = "ball7";
            this.ball7.Size = new System.Drawing.Size(13, 14);
            this.ball7.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.ball7.TabIndex = 191;
            this.ball7.TabStop = false;
            // 
            // ball8
            // 
            this.ball8.Image = global::_13052017_galton.Properties.Resources.Ball;
            this.ball8.Location = new System.Drawing.Point(268, 277);
            this.ball8.Name = "ball8";
            this.ball8.Size = new System.Drawing.Size(13, 14);
            this.ball8.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.ball8.TabIndex = 192;
            this.ball8.TabStop = false;
            // 
            // ball9
            // 
            this.ball9.Image = global::_13052017_galton.Properties.Resources.Ball;
            this.ball9.Location = new System.Drawing.Point(300, 277);
            this.ball9.Name = "ball9";
            this.ball9.Size = new System.Drawing.Size(13, 14);
            this.ball9.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.ball9.TabIndex = 193;
            this.ball9.TabStop = false;
            // 
            // ball10
            // 
            this.ball10.Image = global::_13052017_galton.Properties.Resources.Ball;
            this.ball10.Location = new System.Drawing.Point(332, 277);
            this.ball10.Name = "ball10";
            this.ball10.Size = new System.Drawing.Size(13, 14);
            this.ball10.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.ball10.TabIndex = 194;
            this.ball10.TabStop = false;
            // 
            // ball11
            // 
            this.ball11.Image = global::_13052017_galton.Properties.Resources.Ball;
            this.ball11.Location = new System.Drawing.Point(365, 277);
            this.ball11.Name = "ball11";
            this.ball11.Size = new System.Drawing.Size(13, 14);
            this.ball11.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.ball11.TabIndex = 195;
            this.ball11.TabStop = false;
            // 
            // ball12
            // 
            this.ball12.Image = global::_13052017_galton.Properties.Resources.Ball;
            this.ball12.Location = new System.Drawing.Point(399, 277);
            this.ball12.Name = "ball12";
            this.ball12.Size = new System.Drawing.Size(13, 14);
            this.ball12.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.ball12.TabIndex = 196;
            this.ball12.TabStop = false;
            // 
            // ball13
            // 
            this.ball13.Image = global::_13052017_galton.Properties.Resources.Ball;
            this.ball13.Location = new System.Drawing.Point(433, 276);
            this.ball13.Name = "ball13";
            this.ball13.Size = new System.Drawing.Size(13, 14);
            this.ball13.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.ball13.TabIndex = 197;
            this.ball13.TabStop = false;
            // 
            // labelBall1
            // 
            this.labelBall1.AutoSize = true;
            this.labelBall1.BackColor = System.Drawing.Color.White;
            this.labelBall1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.labelBall1.Location = new System.Drawing.Point(24, 441);
            this.labelBall1.Name = "labelBall1";
            this.labelBall1.Size = new System.Drawing.Size(15, 16);
            this.labelBall1.TabIndex = 199;
            this.labelBall1.Text = "0";
            // 
            // labelBall2
            // 
            this.labelBall2.AutoSize = true;
            this.labelBall2.BackColor = System.Drawing.Color.White;
            this.labelBall2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.labelBall2.Location = new System.Drawing.Point(57, 441);
            this.labelBall2.Name = "labelBall2";
            this.labelBall2.Size = new System.Drawing.Size(15, 16);
            this.labelBall2.TabIndex = 200;
            this.labelBall2.Text = "0";
            // 
            // labelBall3
            // 
            this.labelBall3.AutoSize = true;
            this.labelBall3.BackColor = System.Drawing.Color.White;
            this.labelBall3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.labelBall3.Location = new System.Drawing.Point(91, 441);
            this.labelBall3.Name = "labelBall3";
            this.labelBall3.Size = new System.Drawing.Size(15, 16);
            this.labelBall3.TabIndex = 201;
            this.labelBall3.Text = "0";
            // 
            // labelBall4
            // 
            this.labelBall4.AutoSize = true;
            this.labelBall4.BackColor = System.Drawing.Color.White;
            this.labelBall4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.labelBall4.Location = new System.Drawing.Point(124, 441);
            this.labelBall4.Name = "labelBall4";
            this.labelBall4.Size = new System.Drawing.Size(15, 16);
            this.labelBall4.TabIndex = 202;
            this.labelBall4.Text = "0";
            // 
            // labelBall5
            // 
            this.labelBall5.AutoSize = true;
            this.labelBall5.BackColor = System.Drawing.Color.White;
            this.labelBall5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.labelBall5.Location = new System.Drawing.Point(158, 441);
            this.labelBall5.Name = "labelBall5";
            this.labelBall5.Size = new System.Drawing.Size(15, 16);
            this.labelBall5.TabIndex = 203;
            this.labelBall5.Text = "0";
            // 
            // labelBall6
            // 
            this.labelBall6.AutoSize = true;
            this.labelBall6.BackColor = System.Drawing.Color.White;
            this.labelBall6.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.labelBall6.Location = new System.Drawing.Point(191, 441);
            this.labelBall6.Name = "labelBall6";
            this.labelBall6.Size = new System.Drawing.Size(15, 16);
            this.labelBall6.TabIndex = 204;
            this.labelBall6.Text = "0";
            // 
            // labelBall7
            // 
            this.labelBall7.AutoSize = true;
            this.labelBall7.BackColor = System.Drawing.Color.White;
            this.labelBall7.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.labelBall7.Location = new System.Drawing.Point(224, 441);
            this.labelBall7.Name = "labelBall7";
            this.labelBall7.Size = new System.Drawing.Size(15, 16);
            this.labelBall7.TabIndex = 205;
            this.labelBall7.Text = "0";
            // 
            // labelBall8
            // 
            this.labelBall8.AutoSize = true;
            this.labelBall8.BackColor = System.Drawing.Color.White;
            this.labelBall8.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.labelBall8.Location = new System.Drawing.Point(258, 441);
            this.labelBall8.Name = "labelBall8";
            this.labelBall8.Size = new System.Drawing.Size(15, 16);
            this.labelBall8.TabIndex = 206;
            this.labelBall8.Text = "0";
            // 
            // labelBall9
            // 
            this.labelBall9.AutoSize = true;
            this.labelBall9.BackColor = System.Drawing.Color.White;
            this.labelBall9.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.labelBall9.Location = new System.Drawing.Point(291, 441);
            this.labelBall9.Name = "labelBall9";
            this.labelBall9.Size = new System.Drawing.Size(15, 16);
            this.labelBall9.TabIndex = 207;
            this.labelBall9.Text = "0";
            // 
            // labelBall10
            // 
            this.labelBall10.AutoSize = true;
            this.labelBall10.BackColor = System.Drawing.Color.White;
            this.labelBall10.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.labelBall10.Location = new System.Drawing.Point(324, 441);
            this.labelBall10.Name = "labelBall10";
            this.labelBall10.Size = new System.Drawing.Size(15, 16);
            this.labelBall10.TabIndex = 208;
            this.labelBall10.Text = "0";
            // 
            // labelBall11
            // 
            this.labelBall11.AutoSize = true;
            this.labelBall11.BackColor = System.Drawing.Color.White;
            this.labelBall11.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.labelBall11.Location = new System.Drawing.Point(358, 441);
            this.labelBall11.Name = "labelBall11";
            this.labelBall11.Size = new System.Drawing.Size(15, 16);
            this.labelBall11.TabIndex = 209;
            this.labelBall11.Text = "0";
            // 
            // labelBall12
            // 
            this.labelBall12.AutoSize = true;
            this.labelBall12.BackColor = System.Drawing.Color.White;
            this.labelBall12.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.labelBall12.Location = new System.Drawing.Point(391, 441);
            this.labelBall12.Name = "labelBall12";
            this.labelBall12.Size = new System.Drawing.Size(15, 16);
            this.labelBall12.TabIndex = 210;
            this.labelBall12.Text = "0";
            // 
            // labelBall13
            // 
            this.labelBall13.AutoSize = true;
            this.labelBall13.BackColor = System.Drawing.Color.White;
            this.labelBall13.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.labelBall13.Location = new System.Drawing.Point(425, 441);
            this.labelBall13.Name = "labelBall13";
            this.labelBall13.Size = new System.Drawing.Size(15, 16);
            this.labelBall13.TabIndex = 211;
            this.labelBall13.Text = "0";
            // 
            // timer
            // 
            this.timer.Tick += new System.EventHandler(this.timer_Tick);
            // 
            // notifyIcon1
            // 
            this.notifyIcon1.Text = "notifyIcon1";
            this.notifyIcon1.Visible = true;
            // 
            // toolStrip1
            // 
            this.toolStrip1.GripStyle = System.Windows.Forms.ToolStripGripStyle.Hidden;
            this.toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsbStart,
            this.tsbStop,
            this.tsbPlot,
            this.toolStripSeparator1,
            this.toolStripLabel1,
            this.tstAmount,
            this.toolStripLabel2,
            this.tscbSpeed});
            this.toolStrip1.Location = new System.Drawing.Point(0, 0);
            this.toolStrip1.Name = "toolStrip1";
            this.toolStrip1.Size = new System.Drawing.Size(472, 25);
            this.toolStrip1.TabIndex = 212;
            this.toolStrip1.Text = "toolStrip1";
            // 
            // tsbStart
            // 
            this.tsbStart.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.tsbStart.Image = ((System.Drawing.Image)(resources.GetObject("tsbStart.Image")));
            this.tsbStart.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbStart.Name = "tsbStart";
            this.tsbStart.Size = new System.Drawing.Size(42, 22);
            this.tsbStart.Text = "Старт";
            this.tsbStart.Click += new System.EventHandler(this.tsbStart_Click);
            // 
            // tsbStop
            // 
            this.tsbStop.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.tsbStop.Enabled = false;
            this.tsbStop.Image = ((System.Drawing.Image)(resources.GetObject("tsbStop.Image")));
            this.tsbStop.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbStop.Name = "tsbStop";
            this.tsbStop.Size = new System.Drawing.Size(38, 22);
            this.tsbStop.Text = "Стоп";
            this.tsbStop.Click += new System.EventHandler(this.tsbStop_Click);
            // 
            // tsbPlot
            // 
            this.tsbPlot.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.tsbPlot.Enabled = false;
            this.tsbPlot.Image = ((System.Drawing.Image)(resources.GetObject("tsbPlot.Image")));
            this.tsbPlot.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbPlot.Name = "tsbPlot";
            this.tsbPlot.Size = new System.Drawing.Size(39, 22);
            this.tsbPlot.Text = "Граф";
            this.tsbPlot.Click += new System.EventHandler(this.tsbPlot_Click);
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(6, 25);
            // 
            // toolStripLabel1
            // 
            this.toolStripLabel1.Name = "toolStripLabel1";
            this.toolStripLabel1.Size = new System.Drawing.Size(42, 22);
            this.toolStripLabel1.Text = "Число";
            // 
            // tstAmount
            // 
            this.tstAmount.AutoSize = false;
            this.tstAmount.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.tstAmount.Name = "tstAmount";
            this.tstAmount.Size = new System.Drawing.Size(50, 25);
            this.tstAmount.Text = "80";
            // 
            // toolStripLabel2
            // 
            this.toolStripLabel2.Name = "toolStripLabel2";
            this.toolStripLabel2.Size = new System.Drawing.Size(59, 22);
            this.toolStripLabel2.Text = "Скорость";
            // 
            // tscbSpeed
            // 
            this.tscbSpeed.AutoSize = false;
            this.tscbSpeed.Items.AddRange(new object[] {
            "Медл",
            "Сред",
            "Выс"});
            this.tscbSpeed.Name = "tscbSpeed";
            this.tscbSpeed.Size = new System.Drawing.Size(80, 23);
            this.tscbSpeed.SelectedIndexChanged += new System.EventHandler(this.tscbSpeed_SelectedIndexChanged);
            // 
            // arrow3_3
            // 
            this.arrow3_3.Image = global::_13052017_galton.Properties.Resources.Ball;
            this.arrow3_3.Location = new System.Drawing.Point(220, 103);
            this.arrow3_3.Name = "arrow3_3";
            this.arrow3_3.Size = new System.Drawing.Size(13, 14);
            this.arrow3_3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.arrow3_3.TabIndex = 17;
            this.arrow3_3.TabStop = false;
            // 
            // arrow2_3
            // 
            this.arrow2_3.Image = global::_13052017_galton.Properties.Resources.Ball;
            this.arrow2_3.Location = new System.Drawing.Point(237, 86);
            this.arrow2_3.Name = "arrow2_3";
            this.arrow2_3.Size = new System.Drawing.Size(13, 14);
            this.arrow2_3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.arrow2_3.TabIndex = 16;
            this.arrow2_3.TabStop = false;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(472, 477);
            this.Controls.Add(this.toolStrip1);
            this.Controls.Add(this.plot1);
            this.Controls.Add(this.labelBall13);
            this.Controls.Add(this.labelBall12);
            this.Controls.Add(this.labelBall11);
            this.Controls.Add(this.labelBall10);
            this.Controls.Add(this.labelBall9);
            this.Controls.Add(this.labelBall8);
            this.Controls.Add(this.labelBall7);
            this.Controls.Add(this.labelBall6);
            this.Controls.Add(this.labelBall5);
            this.Controls.Add(this.labelBall4);
            this.Controls.Add(this.labelBall3);
            this.Controls.Add(this.labelBall2);
            this.Controls.Add(this.labelBall1);
            this.Controls.Add(this.ball13);
            this.Controls.Add(this.ball12);
            this.Controls.Add(this.ball11);
            this.Controls.Add(this.ball10);
            this.Controls.Add(this.ball9);
            this.Controls.Add(this.ball8);
            this.Controls.Add(this.ball7);
            this.Controls.Add(this.ball6);
            this.Controls.Add(this.ball5);
            this.Controls.Add(this.ball4);
            this.Controls.Add(this.ball3);
            this.Controls.Add(this.ball2);
            this.Controls.Add(this.ball1);
            this.Controls.Add(this.arrow12_24);
            this.Controls.Add(this.arrow12_22);
            this.Controls.Add(this.arrow11_22);
            this.Controls.Add(this.arrow12_20);
            this.Controls.Add(this.arrow11_20);
            this.Controls.Add(this.arrow10_20);
            this.Controls.Add(this.arrow12_18);
            this.Controls.Add(this.arrow11_18);
            this.Controls.Add(this.arrow10_18);
            this.Controls.Add(this.arrow9_18);
            this.Controls.Add(this.arrow12_16);
            this.Controls.Add(this.arrow11_16);
            this.Controls.Add(this.arrow10_16);
            this.Controls.Add(this.arrow9_16);
            this.Controls.Add(this.arrow8_16);
            this.Controls.Add(this.arrow12_14);
            this.Controls.Add(this.arrow11_14);
            this.Controls.Add(this.arrow10_14);
            this.Controls.Add(this.arrow9_14);
            this.Controls.Add(this.arrow8_14);
            this.Controls.Add(this.arrow7_14);
            this.Controls.Add(this.arrow12_12);
            this.Controls.Add(this.arrow11_12);
            this.Controls.Add(this.arrow10_12);
            this.Controls.Add(this.arrow9_12);
            this.Controls.Add(this.arrow8_12);
            this.Controls.Add(this.arrow7_12);
            this.Controls.Add(this.arrow6_12);
            this.Controls.Add(this.arrow12_10);
            this.Controls.Add(this.arrow11_10);
            this.Controls.Add(this.arrow10_10);
            this.Controls.Add(this.arrow9_10);
            this.Controls.Add(this.arrow8_10);
            this.Controls.Add(this.arrow7_10);
            this.Controls.Add(this.arrow6_10);
            this.Controls.Add(this.arrow5_10);
            this.Controls.Add(this.arrow12_8);
            this.Controls.Add(this.arrow11_8);
            this.Controls.Add(this.arrow10_8);
            this.Controls.Add(this.arrow9_8);
            this.Controls.Add(this.arrow8_8);
            this.Controls.Add(this.arrow7_8);
            this.Controls.Add(this.arrow6_8);
            this.Controls.Add(this.arrow5_8);
            this.Controls.Add(this.arrow4_8);
            this.Controls.Add(this.arrow12_6);
            this.Controls.Add(this.arrow11_6);
            this.Controls.Add(this.arrow10_6);
            this.Controls.Add(this.arrow9_6);
            this.Controls.Add(this.arrow8_6);
            this.Controls.Add(this.arrow7_6);
            this.Controls.Add(this.arrow6_6);
            this.Controls.Add(this.arrow5_6);
            this.Controls.Add(this.arrow4_6);
            this.Controls.Add(this.arrow3_6);
            this.Controls.Add(this.arrow12_4);
            this.Controls.Add(this.arrow11_4);
            this.Controls.Add(this.arrow10_4);
            this.Controls.Add(this.arrow9_4);
            this.Controls.Add(this.arrow8_4);
            this.Controls.Add(this.arrow7_4);
            this.Controls.Add(this.arrow6_4);
            this.Controls.Add(this.arrow5_4);
            this.Controls.Add(this.arrow4_4);
            this.Controls.Add(this.arrow3_4);
            this.Controls.Add(this.arrow2_4);
            this.Controls.Add(this.arrow12_2);
            this.Controls.Add(this.arrow11_2);
            this.Controls.Add(this.arrow10_2);
            this.Controls.Add(this.arrow9_2);
            this.Controls.Add(this.arrow8_2);
            this.Controls.Add(this.arrow7_2);
            this.Controls.Add(this.arrow6_2);
            this.Controls.Add(this.arrow5_2);
            this.Controls.Add(this.arrow4_2);
            this.Controls.Add(this.arrow3_2);
            this.Controls.Add(this.arrow2_2);
            this.Controls.Add(this.arrow1_2);
            this.Controls.Add(this.arrow12_23);
            this.Controls.Add(this.arrow12_21);
            this.Controls.Add(this.arrow11_21);
            this.Controls.Add(this.arrow12_19);
            this.Controls.Add(this.arrow11_19);
            this.Controls.Add(this.arrow10_19);
            this.Controls.Add(this.arrow12_17);
            this.Controls.Add(this.arrow11_17);
            this.Controls.Add(this.arrow10_17);
            this.Controls.Add(this.arrow9_17);
            this.Controls.Add(this.arrow12_15);
            this.Controls.Add(this.arrow11_15);
            this.Controls.Add(this.arrow10_15);
            this.Controls.Add(this.arrow9_15);
            this.Controls.Add(this.arrow8_15);
            this.Controls.Add(this.arrow12_13);
            this.Controls.Add(this.arrow11_13);
            this.Controls.Add(this.arrow10_13);
            this.Controls.Add(this.arrow9_13);
            this.Controls.Add(this.arrow8_13);
            this.Controls.Add(this.arrow7_13);
            this.Controls.Add(this.arrow12_11);
            this.Controls.Add(this.arrow11_11);
            this.Controls.Add(this.arrow10_11);
            this.Controls.Add(this.arrow9_11);
            this.Controls.Add(this.arrow8_11);
            this.Controls.Add(this.arrow7_11);
            this.Controls.Add(this.arrow6_11);
            this.Controls.Add(this.arrow12_9);
            this.Controls.Add(this.arrow11_9);
            this.Controls.Add(this.arrow10_9);
            this.Controls.Add(this.arrow9_9);
            this.Controls.Add(this.arrow8_9);
            this.Controls.Add(this.arrow7_9);
            this.Controls.Add(this.arrow6_9);
            this.Controls.Add(this.arrow5_9);
            this.Controls.Add(this.arrow12_7);
            this.Controls.Add(this.arrow11_7);
            this.Controls.Add(this.arrow10_7);
            this.Controls.Add(this.arrow9_7);
            this.Controls.Add(this.arrow8_7);
            this.Controls.Add(this.arrow7_7);
            this.Controls.Add(this.arrow6_7);
            this.Controls.Add(this.arrow5_7);
            this.Controls.Add(this.arrow4_7);
            this.Controls.Add(this.arrow12_5);
            this.Controls.Add(this.arrow11_5);
            this.Controls.Add(this.arrow10_5);
            this.Controls.Add(this.arrow9_5);
            this.Controls.Add(this.arrow8_5);
            this.Controls.Add(this.arrow7_5);
            this.Controls.Add(this.arrow6_5);
            this.Controls.Add(this.arrow5_5);
            this.Controls.Add(this.arrow4_5);
            this.Controls.Add(this.arrow3_5);
            this.Controls.Add(this.arrow12_3);
            this.Controls.Add(this.arrow11_3);
            this.Controls.Add(this.arrow10_3);
            this.Controls.Add(this.arrow9_3);
            this.Controls.Add(this.arrow8_3);
            this.Controls.Add(this.arrow7_3);
            this.Controls.Add(this.arrow6_3);
            this.Controls.Add(this.arrow5_3);
            this.Controls.Add(this.arrow4_3);
            this.Controls.Add(this.arrow3_3);
            this.Controls.Add(this.arrow2_3);
            this.Controls.Add(this.arrow12_1);
            this.Controls.Add(this.arrow11_1);
            this.Controls.Add(this.arrow10_1);
            this.Controls.Add(this.arrow9_1);
            this.Controls.Add(this.arrow8_1);
            this.Controls.Add(this.arrow7_1);
            this.Controls.Add(this.arrow6_1);
            this.Controls.Add(this.arrow5_1);
            this.Controls.Add(this.arrow4_1);
            this.Controls.Add(this.arrow3_1);
            this.Controls.Add(this.arrow2_1);
            this.Controls.Add(this.arrow1_1);
            this.Controls.Add(this.arrow0);
            this.Controls.Add(this.ball0);
            this.Controls.Add(this.pictureBox1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Form1";
            this.Text = "Galton\'s Desk";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ball0)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.arrow0)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.arrow1_1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.arrow2_1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.arrow3_1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.arrow4_1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.arrow5_1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.arrow6_1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.arrow7_1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.arrow8_1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.arrow9_1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.arrow10_1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.arrow11_1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.arrow12_1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.arrow12_3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.arrow11_3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.arrow10_3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.arrow9_3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.arrow8_3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.arrow7_3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.arrow6_3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.arrow5_3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.arrow4_3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.arrow12_5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.arrow11_5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.arrow10_5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.arrow9_5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.arrow8_5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.arrow7_5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.arrow6_5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.arrow5_5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.arrow4_5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.arrow3_5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.arrow12_7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.arrow11_7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.arrow10_7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.arrow9_7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.arrow8_7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.arrow7_7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.arrow6_7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.arrow5_7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.arrow4_7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.arrow12_9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.arrow11_9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.arrow10_9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.arrow9_9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.arrow8_9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.arrow7_9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.arrow6_9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.arrow5_9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.arrow12_11)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.arrow11_11)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.arrow10_11)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.arrow9_11)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.arrow8_11)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.arrow7_11)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.arrow6_11)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.arrow12_13)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.arrow11_13)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.arrow10_13)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.arrow9_13)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.arrow8_13)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.arrow7_13)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.arrow12_15)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.arrow11_15)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.arrow10_15)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.arrow9_15)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.arrow8_15)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.arrow12_17)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.arrow11_17)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.arrow10_17)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.arrow9_17)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.arrow12_19)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.arrow11_19)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.arrow10_19)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.arrow12_21)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.arrow11_21)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.arrow12_23)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.arrow12_24)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.arrow12_22)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.arrow11_22)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.arrow12_20)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.arrow11_20)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.arrow10_20)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.arrow12_18)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.arrow11_18)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.arrow10_18)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.arrow9_18)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.arrow12_16)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.arrow11_16)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.arrow10_16)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.arrow9_16)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.arrow8_16)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.arrow12_14)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.arrow11_14)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.arrow10_14)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.arrow9_14)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.arrow8_14)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.arrow7_14)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.arrow12_12)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.arrow11_12)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.arrow10_12)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.arrow9_12)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.arrow8_12)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.arrow7_12)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.arrow6_12)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.arrow12_10)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.arrow11_10)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.arrow10_10)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.arrow9_10)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.arrow8_10)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.arrow7_10)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.arrow6_10)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.arrow5_10)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.arrow12_8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.arrow11_8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.arrow10_8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.arrow9_8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.arrow8_8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.arrow7_8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.arrow6_8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.arrow5_8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.arrow4_8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.arrow12_6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.arrow11_6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.arrow10_6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.arrow9_6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.arrow8_6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.arrow7_6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.arrow6_6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.arrow5_6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.arrow4_6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.arrow3_6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.arrow12_4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.arrow11_4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.arrow10_4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.arrow9_4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.arrow8_4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.arrow7_4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.arrow6_4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.arrow5_4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.arrow4_4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.arrow3_4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.arrow2_4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.arrow12_2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.arrow11_2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.arrow10_2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.arrow9_2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.arrow8_2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.arrow7_2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.arrow6_2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.arrow5_2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.arrow4_2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.arrow3_2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.arrow2_2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.arrow1_2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ball1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ball2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ball3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ball4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ball5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ball6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ball7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ball8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ball9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ball10)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ball11)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ball12)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ball13)).EndInit();
            this.toolStrip1.ResumeLayout(false);
            this.toolStrip1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.arrow3_3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.arrow2_3)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private OxyPlot.WindowsForms.PlotView plot1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.PictureBox ball0;
        private System.Windows.Forms.PictureBox arrow0;
        private System.Windows.Forms.PictureBox arrow1_1;
        private System.Windows.Forms.PictureBox arrow2_1;
        private System.Windows.Forms.PictureBox arrow3_1;
        private System.Windows.Forms.PictureBox arrow4_1;
        private System.Windows.Forms.PictureBox arrow5_1;
        private System.Windows.Forms.PictureBox arrow6_1;
        private System.Windows.Forms.PictureBox arrow7_1;
        private System.Windows.Forms.PictureBox arrow8_1;
        private System.Windows.Forms.PictureBox arrow9_1;
        private System.Windows.Forms.PictureBox arrow10_1;
        private System.Windows.Forms.PictureBox arrow11_1;
        private System.Windows.Forms.PictureBox arrow12_1;
        private System.Windows.Forms.PictureBox arrow12_3;
        private System.Windows.Forms.PictureBox arrow11_3;
        private System.Windows.Forms.PictureBox arrow10_3;
        private System.Windows.Forms.PictureBox arrow9_3;
        private System.Windows.Forms.PictureBox arrow8_3;
        private System.Windows.Forms.PictureBox arrow7_3;
        private System.Windows.Forms.PictureBox arrow6_3;
        private System.Windows.Forms.PictureBox arrow5_3;
        private System.Windows.Forms.PictureBox arrow4_3;
        private System.Windows.Forms.PictureBox arrow12_5;
        private System.Windows.Forms.PictureBox arrow11_5;
        private System.Windows.Forms.PictureBox arrow10_5;
        private System.Windows.Forms.PictureBox arrow9_5;
        private System.Windows.Forms.PictureBox arrow8_5;
        private System.Windows.Forms.PictureBox arrow7_5;
        private System.Windows.Forms.PictureBox arrow6_5;
        private System.Windows.Forms.PictureBox arrow5_5;
        private System.Windows.Forms.PictureBox arrow4_5;
        private System.Windows.Forms.PictureBox arrow3_5;
        private System.Windows.Forms.PictureBox arrow12_7;
        private System.Windows.Forms.PictureBox arrow11_7;
        private System.Windows.Forms.PictureBox arrow10_7;
        private System.Windows.Forms.PictureBox arrow9_7;
        private System.Windows.Forms.PictureBox arrow8_7;
        private System.Windows.Forms.PictureBox arrow7_7;
        private System.Windows.Forms.PictureBox arrow6_7;
        private System.Windows.Forms.PictureBox arrow5_7;
        private System.Windows.Forms.PictureBox arrow4_7;
        private System.Windows.Forms.PictureBox arrow12_9;
        private System.Windows.Forms.PictureBox arrow11_9;
        private System.Windows.Forms.PictureBox arrow10_9;
        private System.Windows.Forms.PictureBox arrow9_9;
        private System.Windows.Forms.PictureBox arrow8_9;
        private System.Windows.Forms.PictureBox arrow7_9;
        private System.Windows.Forms.PictureBox arrow6_9;
        private System.Windows.Forms.PictureBox arrow5_9;
        private System.Windows.Forms.PictureBox arrow12_11;
        private System.Windows.Forms.PictureBox arrow11_11;
        private System.Windows.Forms.PictureBox arrow10_11;
        private System.Windows.Forms.PictureBox arrow9_11;
        private System.Windows.Forms.PictureBox arrow8_11;
        private System.Windows.Forms.PictureBox arrow7_11;
        private System.Windows.Forms.PictureBox arrow6_11;
        private System.Windows.Forms.PictureBox arrow12_13;
        private System.Windows.Forms.PictureBox arrow11_13;
        private System.Windows.Forms.PictureBox arrow10_13;
        private System.Windows.Forms.PictureBox arrow9_13;
        private System.Windows.Forms.PictureBox arrow8_13;
        private System.Windows.Forms.PictureBox arrow7_13;
        private System.Windows.Forms.PictureBox arrow12_15;
        private System.Windows.Forms.PictureBox arrow11_15;
        private System.Windows.Forms.PictureBox arrow10_15;
        private System.Windows.Forms.PictureBox arrow9_15;
        private System.Windows.Forms.PictureBox arrow8_15;
        private System.Windows.Forms.PictureBox arrow12_17;
        private System.Windows.Forms.PictureBox arrow11_17;
        private System.Windows.Forms.PictureBox arrow10_17;
        private System.Windows.Forms.PictureBox arrow9_17;
        private System.Windows.Forms.PictureBox arrow12_19;
        private System.Windows.Forms.PictureBox arrow11_19;
        private System.Windows.Forms.PictureBox arrow10_19;
        private System.Windows.Forms.PictureBox arrow12_21;
        private System.Windows.Forms.PictureBox arrow11_21;
        private System.Windows.Forms.PictureBox arrow12_23;
        private System.Windows.Forms.PictureBox arrow12_24;
        private System.Windows.Forms.PictureBox arrow12_22;
        private System.Windows.Forms.PictureBox arrow11_22;
        private System.Windows.Forms.PictureBox arrow12_20;
        private System.Windows.Forms.PictureBox arrow11_20;
        private System.Windows.Forms.PictureBox arrow10_20;
        private System.Windows.Forms.PictureBox arrow12_18;
        private System.Windows.Forms.PictureBox arrow11_18;
        private System.Windows.Forms.PictureBox arrow10_18;
        private System.Windows.Forms.PictureBox arrow9_18;
        private System.Windows.Forms.PictureBox arrow12_16;
        private System.Windows.Forms.PictureBox arrow11_16;
        private System.Windows.Forms.PictureBox arrow10_16;
        private System.Windows.Forms.PictureBox arrow9_16;
        private System.Windows.Forms.PictureBox arrow8_16;
        private System.Windows.Forms.PictureBox arrow12_14;
        private System.Windows.Forms.PictureBox arrow11_14;
        private System.Windows.Forms.PictureBox arrow10_14;
        private System.Windows.Forms.PictureBox arrow9_14;
        private System.Windows.Forms.PictureBox arrow8_14;
        private System.Windows.Forms.PictureBox arrow7_14;
        private System.Windows.Forms.PictureBox arrow12_12;
        private System.Windows.Forms.PictureBox arrow11_12;
        private System.Windows.Forms.PictureBox arrow10_12;
        private System.Windows.Forms.PictureBox arrow9_12;
        private System.Windows.Forms.PictureBox arrow8_12;
        private System.Windows.Forms.PictureBox arrow7_12;
        private System.Windows.Forms.PictureBox arrow6_12;
        private System.Windows.Forms.PictureBox arrow12_10;
        private System.Windows.Forms.PictureBox arrow11_10;
        private System.Windows.Forms.PictureBox arrow10_10;
        private System.Windows.Forms.PictureBox arrow9_10;
        private System.Windows.Forms.PictureBox arrow8_10;
        private System.Windows.Forms.PictureBox arrow7_10;
        private System.Windows.Forms.PictureBox arrow6_10;
        private System.Windows.Forms.PictureBox arrow5_10;
        private System.Windows.Forms.PictureBox arrow12_8;
        private System.Windows.Forms.PictureBox arrow11_8;
        private System.Windows.Forms.PictureBox arrow10_8;
        private System.Windows.Forms.PictureBox arrow9_8;
        private System.Windows.Forms.PictureBox arrow8_8;
        private System.Windows.Forms.PictureBox arrow7_8;
        private System.Windows.Forms.PictureBox arrow6_8;
        private System.Windows.Forms.PictureBox arrow5_8;
        private System.Windows.Forms.PictureBox arrow4_8;
        private System.Windows.Forms.PictureBox arrow12_6;
        private System.Windows.Forms.PictureBox arrow11_6;
        private System.Windows.Forms.PictureBox arrow10_6;
        private System.Windows.Forms.PictureBox arrow9_6;
        private System.Windows.Forms.PictureBox arrow8_6;
        private System.Windows.Forms.PictureBox arrow7_6;
        private System.Windows.Forms.PictureBox arrow6_6;
        private System.Windows.Forms.PictureBox arrow5_6;
        private System.Windows.Forms.PictureBox arrow4_6;
        private System.Windows.Forms.PictureBox arrow3_6;
        private System.Windows.Forms.PictureBox arrow12_4;
        private System.Windows.Forms.PictureBox arrow11_4;
        private System.Windows.Forms.PictureBox arrow10_4;
        private System.Windows.Forms.PictureBox arrow9_4;
        private System.Windows.Forms.PictureBox arrow8_4;
        private System.Windows.Forms.PictureBox arrow7_4;
        private System.Windows.Forms.PictureBox arrow6_4;
        private System.Windows.Forms.PictureBox arrow5_4;
        private System.Windows.Forms.PictureBox arrow4_4;
        private System.Windows.Forms.PictureBox arrow3_4;
        private System.Windows.Forms.PictureBox arrow2_4;
        private System.Windows.Forms.PictureBox arrow12_2;
        private System.Windows.Forms.PictureBox arrow11_2;
        private System.Windows.Forms.PictureBox arrow10_2;
        private System.Windows.Forms.PictureBox arrow9_2;
        private System.Windows.Forms.PictureBox arrow8_2;
        private System.Windows.Forms.PictureBox arrow7_2;
        private System.Windows.Forms.PictureBox arrow6_2;
        private System.Windows.Forms.PictureBox arrow5_2;
        private System.Windows.Forms.PictureBox arrow4_2;
        private System.Windows.Forms.PictureBox arrow3_2;
        private System.Windows.Forms.PictureBox arrow2_2;
        private System.Windows.Forms.PictureBox arrow1_2;
        private System.Windows.Forms.PictureBox ball1;
        private System.Windows.Forms.PictureBox ball2;
        private System.Windows.Forms.PictureBox ball3;
        private System.Windows.Forms.PictureBox ball4;
        private System.Windows.Forms.PictureBox ball5;
        private System.Windows.Forms.PictureBox ball6;
        private System.Windows.Forms.PictureBox ball7;
        private System.Windows.Forms.PictureBox ball8;
        private System.Windows.Forms.PictureBox ball9;
        private System.Windows.Forms.PictureBox ball10;
        private System.Windows.Forms.PictureBox ball11;
        private System.Windows.Forms.PictureBox ball12;
        private System.Windows.Forms.PictureBox ball13;
        private System.Windows.Forms.Label labelBall1;
        private System.Windows.Forms.Label labelBall2;
        private System.Windows.Forms.Label labelBall3;
        private System.Windows.Forms.Label labelBall4;
        private System.Windows.Forms.Label labelBall5;
        private System.Windows.Forms.Label labelBall6;
        private System.Windows.Forms.Label labelBall7;
        private System.Windows.Forms.Label labelBall8;
        private System.Windows.Forms.Label labelBall9;
        private System.Windows.Forms.Label labelBall10;
        private System.Windows.Forms.Label labelBall11;
        private System.Windows.Forms.Label labelBall12;
        private System.Windows.Forms.Label labelBall13;
        private System.Windows.Forms.Timer timer;
        private System.Windows.Forms.NotifyIcon notifyIcon1;
        private System.Windows.Forms.ToolStrip toolStrip1;
        private System.Windows.Forms.ToolStripButton tsbStart;
        private System.Windows.Forms.ToolStripButton tsbStop;
        private System.Windows.Forms.ToolStripButton tsbPlot;
        private System.Windows.Forms.ToolStripLabel toolStripLabel1;
        private System.Windows.Forms.ToolStripTextBox tstAmount;
        private System.Windows.Forms.ToolStripLabel toolStripLabel2;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripComboBox tscbSpeed;
        private System.Windows.Forms.PictureBox arrow3_3;
        private System.Windows.Forms.PictureBox arrow2_3;
    }
}

