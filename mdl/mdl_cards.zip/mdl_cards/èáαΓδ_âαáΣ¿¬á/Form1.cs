﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Карты_Графика
{
    public partial class Form1 : Form
    {
        //Button[,] CardList = new Button[4, 9];
        List<List<Button>> CardList = new List<List<Button>>();

        int n = 36;
        double bord1 = 0.25;
        double bord2 = 0.5;
        double bord3 = 0.75;

        public void GenerateCards()
        {
            // БУБИ
            CardList.Add(new List<Button> {button1, button2 , button3 , button4 , button5 , button6 , button7 , button8 , button9 });
            /*CardList[0, 0] = button1;
            CardList[1, 0] = button2;
            CardList[2, 0] = button3;
            CardList[3, 0] = button4;
            CardList[4, 0] = button5;
            CardList[5, 0] = button6;
            CardList[6, 0] = button7;
            CardList[7, 0] = button8;
            CardList[8, 0] = button9;*/


            // ПИКИ
            CardList.Add(new List<Button> { button18, button17, button16, button15, button14, button13, button12, button11, button10 });
            /*CardList[0, 1] = button18;
            CardList[1, 1] = button17;
            CardList[2, 1] = button16;
            CardList[3, 1] = button15;
            CardList[4, 1] = button14;
            CardList[5, 1] = button13;
            CardList[6, 1] = button12;
            CardList[7, 1] = button11;
            CardList[8, 1] = button10;*/


            // ЧЕРВИ
            CardList.Add(new List<Button> { button27, button26, button25, button24, button23, button22, button21, button20, button19 });
            /*CardList[0, 2] = button27;
            CardList[1, 2] = button26;
            CardList[2, 2] = button25;
            CardList[3, 2] = button24;
            CardList[4, 2] = button23;
            CardList[5, 2] = button22;
            CardList[6, 2] = button21;
            CardList[7, 2] = button20;
            CardList[8, 2] = button19;*/


            // КРЕСТИ
            CardList.Add(new List<Button> { button36, button35, button34, button33, button32, button31, button30, button29, button28 });
            /*CardList[0, 3] = button36;
            CardList[1, 3] = button35;
            CardList[2, 3] = button34;
            CardList[3, 3] = button33;
            CardList[4, 3] = button32;
            CardList[5, 3] = button31;
            CardList[6, 3] = button30;
            CardList[7, 3] = button29;
            CardList[8, 3] = button28;*/
        }

        public void Calculate()
        {
            Random r = new Random();
            GenerateCards();
            if (n > 0)
            {
                double request = r.NextDouble();
                richTextBox1.Text += "Request = " + request + Environment.NewLine;
                if (request < bord1)
                {
                    if (CardList[0].Count() != 0)
                    {
                        CardList[0][0].Dispose();
                        CardList[0].RemoveAt(0);
                        int k = CardList[0].Count;
                    }
                }
                if ((request >= bord1) && (request < bord2))
                {
                    if (CardList[1].Count() != 0)
                    {
                        CardList[1][0].Dispose();
                        CardList[1].RemoveAt(0);
                    }
                }
                if ((request >= bord2) && (request < bord3))
                {
                    if (CardList[2].Count() != 0)
                    {
                        CardList[2][0].Dispose();
                        CardList[2].RemoveAt(0);
                    }
                }
                if ((request >= bord3) && (request < 1.0))
                {
                    if (CardList[3].Count() != 0)
                    {
                        CardList[3][0].Dispose();
                        CardList[3].RemoveAt(0);
                    }
                }

                n -= 1;
                bord1 = CardList[0].Count / (double)n;
                bord2 = CardList[1].Count / (double)n + bord1;
                bord3 = CardList[2].Count / (double)n + bord2;
                //print("[0 ; " + str(bord1) + " );[ " + str(bord1) + " ; " + str(bord2) + " );[ " + str(bord2) + " ; " + str(bord3) + " );[ " + str(bord3) + " ; 1]");
                richTextBox1.Text = string.Empty;
                richTextBox1.Text += "[0 ; " + Math.Round(bord1, 2) + " );[ " + Math.Round(bord1, 2) + " ; " + Math.Round(bord2, 2) + " );[ " + Math.Round(bord2, 2) + " ; " + Math.Round(bord3, 2) + " );[ " + Math.Round(bord3, 2) + " ; 1]" + Environment.NewLine;
                richTextBox1.Text += "Бубей = " + CardList[0].Count + Environment.NewLine;
                richTextBox1.Text += "Пик = " + CardList[1].Count + Environment.NewLine;
                richTextBox1.Text += "Червей = " + CardList[2].Count + Environment.NewLine;
                richTextBox1.Text += "Крести = " + CardList[3].Count + Environment.NewLine;
                richTextBox1.Text += Environment.NewLine;
            }
        }

        public Form1()
        {
            InitializeComponent();

            foreach (var button in this.Controls.OfType<Button>())
            {
                if (button.Text.Contains("button"))
                    button.Text = string.Empty;
            }
        }

        

        
       

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button37_Click(object sender, EventArgs e)
        {
            Calculate();
        }
    }
}
